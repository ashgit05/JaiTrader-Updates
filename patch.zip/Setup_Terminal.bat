@echo off
title Jai Trader - System Setup
color 0B
cls

echo ========================================================
echo     JAI TRADER TERMINAL - SAFE INSTALLER
echo ========================================================
echo.

:: Clean up any broken files from previous crashes
if exist python_installer.exe del python_installer.exe
if exist node_installer.msi del node_installer.msi

cd /d "%~dp0"

:: ==========================================
:: 1. CHECK AND INSTALL PYTHON
:: ==========================================
echo [1/3] Checking Python installation...
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo Python not found! Downloading official Python 3.11...
    curl -L -o python_installer.exe https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
    
    echo.
    echo ========================================================
    echo ATTENTION: The Python Installer will now open.
    echo CRITICAL: You MUST check the box that says "Add python.exe to PATH" 
    echo at the bottom of the installer window before clicking Install!
    echo ========================================================
    echo.
    
    start /wait python_installer.exe
    del python_installer.exe
) else (
    echo Python is already installed.
)
echo.

:: ==========================================
:: 2. CHECK AND INSTALL NODE.JS
:: ==========================================
echo [2/3] Checking Node.js installation...
node -v >nul 2>&1
if %errorLevel% neq 0 (
    echo Node.js not found! Downloading Node.js 20 LTS...
    curl -L -o node_installer.msi https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi
    
    echo.
    echo ========================================================
    echo ATTENTION: The Node.js Installer will now open.
    echo Please click "Next" through the standard setup prompts.
    echo ========================================================
    echo.
    
    start /wait msiexec /i node_installer.msi
    del node_installer.msi
) else (
    echo Node.js is already installed.
)
echo.

:: ==========================================
:: 3. REFRESH PATH VARIABLES
:: ==========================================
echo [3/3] Refreshing environment variables...
set "PATH=%PATH%;C:\Program Files\nodejs\;C:\Program Files\Python311\;C:\Program Files\Python311\Scripts;%USERPROFILE%\AppData\Roaming\npm;%LocalAppData%\Programs\Python\Python311\;%LocalAppData%\Programs\Python\Python311\Scripts\"
echo.

echo ========================================================
echo 🎉 DEPENDENCIES INSTALLED SUCCESSFULLY!
echo ========================================================
echo You can now close this window and use the Desktop shortcut to start trading.
echo.
pause