@echo off
setlocal
cd /d "%~dp0"
title JAI TRADER v7.0.24

echo ================================================================
echo   JAI TRADER v7.0.24 - ONE-SERVER LAUNCHER rev.6
echo   ONE console, ONE browser window, ONE URL
echo ================================================================

REM ---- 1) find backend.exe: this folder, else any first-level subfolder
set "BEDIR="
if exist "backend.exe" set "BEDIR=%cd%"
if not defined BEDIR (
    for /d %%D in (*) do (
        if exist "%%D\backend.exe" set "BEDIR=%cd%\%%D"
    )
)
if not defined BEDIR (
    echo.
    echo [ERROR] backend.exe not found in this folder or its subfolders:
    echo    %cd%
    echo.
    echo Build it first:
    echo    python -m PyInstaller --onefile --name backend api_server.py --distpath . --clean
    echo.
    pause
    exit /b 1
)
cd /d "%BEDIR%"
echo [OK] backend : %BEDIR%\backend.exe

REM ---- 2) find the built frontend dist\index.html: here, else one level down
set "DISTDIR="
if exist "dist\index.html" set "DISTDIR=%cd%\dist"
if not defined DISTDIR (
    for /d %%D in (*) do (
        if not "%%D"=="node_modules" if exist "%%D\dist\index.html" set "DISTDIR=%cd%\%%D\dist"
    )
)
if defined DISTDIR (
    echo [OK] frontend build: %DISTDIR%
) else (
    echo [WARN] no dist\index.html found here or in subfolders.
    echo        The backend will start API-only and NO terminal page will show.
    echo        Fix: run "npm run build" in the react project, then restart.
)

REM ---- 3) if the build lives in a subfolder, sync it next to backend.exe
if defined DISTDIR if /I not "%DISTDIR%"=="%BEDIR%\dist" (
    echo [SETUP] copying latest frontend build next to backend.exe ...
    xcopy /E /I /Y "%DISTDIR%" "%BEDIR%\dist" >nul
    if errorlevel 1 echo [WARN] copy failed - the backend will try to find dist by itself.
)

echo.
echo Starting backend ... the terminal opens at http://127.0.0.1:8000/
echo Keep this window OPEN - closing it stops the terminal. Ctrl+C stops it.
echo.
backend.exe
echo.
echo Backend exited. Read any error above, then close this window.
pause
