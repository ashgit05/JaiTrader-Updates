@echo off
title Nifty Strategy Terminal Launcher
color 0B

echo ===================================================
echo     Starting Optimized Nifty Terminal...
echo ===================================================
echo.

cd /d "%~dp0"

:: v6.1.5: kill any stale backend from a previous session.
:: Without this, a fresh backend.exe silently dies with "port in use"
:: while an OLD instance keeps serving port 8000.
echo [1/4] Stopping any previous backend instance...
tasklist /FI "IMAGENAME eq backend.exe" | find /I "backend.exe" >nul
if %errorLevel% equ 0 (
    taskkill /F /IM backend.exe >nul 2>&1
    timeout /t 2 /nobreak >nul
)

:: Sanity checks - fail loudly instead of serving nothing
if not exist "backend.exe" (
    color 0C
    echo [ERROR] backend.exe not found in %~dp0
    echo The backend must be built before the terminal can run.
    pause
    exit /b 1
)
if not exist "dist\index.html" (
    color 0C
    echo [ERROR] Frontend not built - dist\index.html not found.
    echo Run "npm run build" before launching.
    pause
    exit /b 1
)

echo [2/4] Starting Python Backend Server (Secure Engine)...
start "Python Backend" /min cmd /k "backend.exe"

echo [3/4] Starting Lightweight Frontend Server (User Interface)...
start "React Frontend" /min cmd /k "python -m http.server 5173 --directory dist"

echo [4/4] Warming up servers (Waiting 5 seconds)...
timeout /t 5 /nobreak > nul

echo Opening your trading dashboard...
start http://localhost:5173/

echo.
echo SUCCESS! The terminal is now live.
echo You can safely close this window. The two minimized windows on your taskbar will keep the app running.
timeout /t 5 > nul
exit