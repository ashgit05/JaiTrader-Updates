@echo off
title Nifty Strategy Terminal Launcher
color 0B

echo ===================================================
echo     Starting Optimized Nifty Terminal...
echo ===================================================
echo.

:: Navigate to the exact folder where this .bat file lives
cd /d "%~dp0"

echo [1/3] Starting Python Backend Server (Angel One Data Bridge)...
:: This opens a new minimized background window running your Python API
start "Python Backend" /min cmd /k "python -m uvicorn api_server:app --reload"

echo [2/3] Starting Lightweight Frontend Server (User Interface)...
:: THIS IS THE CHANGE: Serves the optimized "dist" folder using almost 0 RAM!
start "React Frontend" /min cmd /k "python -m http.server 5173 --directory dist"

echo [3/3] Warming up servers (Waiting 5 seconds)...
timeout /t 5 /nobreak > nul

echo Opening your trading dashboard...
start http://localhost:5173/

echo.
echo ✅ SUCCESS! The terminal is now live.
echo You can safely close this window. The two minimized windows on your taskbar will keep the app running.
timeout /t 5 > nul
exit