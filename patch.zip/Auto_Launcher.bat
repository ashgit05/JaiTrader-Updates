@echo off
title Jai Trader - Initializing...
color 0B
cd /d "%~dp0"

echo ========================================================
echo     JAI TRADER TERMINAL
echo ========================================================
echo.

set "VERSION_URL=https://raw.githubusercontent.com/ashgit05/JaiTrader-Updates/refs/heads/main/version.txt"
set "ZIP_URL=https://raw.githubusercontent.com/ashgit05/JaiTrader-Updates/refs/heads/main/patch.zip"

if not exist "local_version.txt" echo 1.0 > local_version.txt
set /p LOCAL_VER=<local_version.txt
set LOCAL_VER=%LOCAL_VER: =%

echo Checking for updates...
curl -s -f "%VERSION_URL%" > live_version.txt

if not exist "live_version.txt" (
    echo [Network] Starting in offline mode...
    goto :START_APP
)

set /p LIVE_VER=<live_version.txt
set LIVE_VER=%LIVE_VER: =%

if "%LOCAL_VER%"=="%LIVE_VER%" (
    echo Terminal is up to date [v%LOCAL_VER%].
    del live_version.txt >nul 2>&1
    goto :START_APP
)

echo.
echo ========================================================
echo   NEW UPDATE FOUND: v%LIVE_VER%
echo   Downloading from secure cloud server... Please wait.
echo ========================================================

:: v6.1.6: kill any running backend BEFORE updating. A running (locked)
:: backend.exe makes extraction fail mid-way and leaves a corrupt install
:: with no working rollback.
tasklist /FI "IMAGENAME eq backend.exe" | find /I "backend.exe" >nul
if %errorLevel% equ 0 (
    echo Closing running backend for update...
    taskkill /F /IM backend.exe >nul 2>&1
    timeout /t 2 /nobreak >nul
)

curl -L -o patch.zip "%ZIP_URL%"

echo.
echo Verifying update integrity...
:: Verify zip is not corrupt before extracting
tar.exe -tf patch.zip >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] Downloaded patch is corrupted. Aborting update.
    del patch.zip >nul 2>&1
    del live_version.txt >nul 2>&1
    goto :START_APP
)

echo Installing new features...
:: Backup critical files before overwriting
:: v6.1.6: backend.exe and Start_Terminal.bat are now backed up too —
:: they are part of every patch, so the rollback must cover them.
if not exist ".backup_pre_patch" mkdir ".backup_pre_patch"
copy /Y "api_server.py" ".backup_pre_patch\" >nul 2>&1
copy /Y "src\App.jsx" ".backup_pre_patch\" >nul 2>&1
copy /Y "backend.exe" ".backup_pre_patch\" >nul 2>&1
copy /Y "Start_Terminal.bat" ".backup_pre_patch\" >nul 2>&1
xcopy /E /I /Y "dist" ".backup_pre_patch\dist" >nul 2>&1

tar.exe -xf patch.zip
if %errorLevel% neq 0 (
    echo [ERROR] Extraction failed! Restoring previous version...
    copy /Y ".backup_pre_patch\api_server.py" "." >nul 2>&1
    copy /Y ".backup_pre_patch\App.jsx" "src\" >nul 2>&1
    copy /Y ".backup_pre_patch\backend.exe" "." >nul 2>&1
    copy /Y ".backup_pre_patch\Start_Terminal.bat" "." >nul 2>&1
    xcopy /E /I /Y ".backup_pre_patch\dist" "dist" >nul 2>&1
    del patch.zip >nul 2>&1
    del live_version.txt >nul 2>&1
    goto :START_APP
)

timeout /t 1 >nul

echo %LIVE_VER% > local_version.txt
del patch.zip >nul 2>&1
del live_version.txt >nul 2>&1
echo.
echo Update v%LIVE_VER% installed successfully!

:START_APP
echo.
echo Launching Terminal...
timeout /t 2 >nul
start Start_Terminal.bat
exit