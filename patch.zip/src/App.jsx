import React, { useState, useEffect, useRef } from 'react';
import { Activity, Plus, X, ShieldAlert, CheckCircle, Info, TrendingUp, Trash2, ChevronDown, ChevronUp, Download, Lock, Key, Settings, BarChart2, Calendar, Target, Award } from 'lucide-react';

const API_BASE = "http://127.0.0.1:8000/api";

// Pure Math Greek Engine
const erf = (x) => {
  const sign = (x >= 0) ? 1 : -1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
};
const normCdf = (x) => (1.0 + erf(x / Math.sqrt(2.0))) / 2.0;
const normPdf = (x) => Math.exp(-0.5 * x * x) / Math.sqrt(2.0 * Math.PI);

const calculateGreeks = (type, S, K, daysToExpiry, r, marketPrice) => {
  const T = Math.max(daysToExpiry / 365.0, 0.001);
  if (marketPrice <= 0 || S <= 0) return { delta: "0.00", theta: "0.0", iv: "0.0" };

  let high = 2.0, low = 0.0001;
  const cpFlag = type === 'CE' ? 'c' : 'p';
  
  for (let i = 0; i < 30; i++) {
    let mid = (high + low) / 2;
    let d1 = (Math.log(S / K) + (r + 0.5 * mid * mid) * T) / (mid * Math.sqrt(T));
    let d2 = d1 - mid * Math.sqrt(T);
    let price = cpFlag === 'c' 
      ? S * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2)
      : K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
    if (price > marketPrice) high = mid; else low = mid;
  }
  
  let iv = (high + low) / 2;
  let d1 = (Math.log(S / K) + (r + 0.5 * iv * iv) * T) / (iv * Math.sqrt(T));
  let d2 = d1 - iv * Math.sqrt(T);
  
  let delta = cpFlag === 'c' ? normCdf(d1) : normCdf(d1) - 1.0;
  let theta = cpFlag === 'c' ? (- (S * iv * normPdf(d1)) / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * normCdf(d2)) / 365 : (- (S * iv * normPdf(d1)) / (2 * Math.sqrt(T)) + r * K * Math.exp(-r * T) * normCdf(-d2)) / 365;

  return { delta: delta.toFixed(2), theta: theta.toFixed(1), iv: (iv * 100).toFixed(1) };
};

const cleanChartData = (data) => {
  if (!data || !Array.isArray(data)) return [];
  const seen = new Set();
  return data.filter(d => {
      if (seen.has(d.time)) return false;
      seen.add(d.time);
      return true;
  }).sort((a,b) => a.time - b.time);
};

function NiftyStrategyTerminal() {
  // Application State
  const [appState, setAppState] = useState('CHECKING'); // CHECKING, LICENSE_REQ, CREDS_REQ, READY
  const [hwid, setHwid] = useState('');
  const [activeTab, setActiveTab] = useState('TERMINAL'); // TERMINAL, ANALYTICS

  // User Data State (Synced with Backend File)
  const [balance, setBalance] = useState(500000);
  const [activeTrade, setActiveTrade] = useState({ status: 'NONE', strategy: '', expiry: '', legs: [], entryTime: '' });
  const [tradeHistory, setTradeHistory] = useState([]);
  
  const [backendStatus, setBackendStatus] = useState("Connecting...");
  const [market, setMarket] = useState({ spot: 0, is_live: false, indicators: {sma20:0, rsi:0, rsi_sig:0}, algo: {signal:"WAIT", details:""} });
  const [chainData, setChainData] = useState({ expiries: [], strikes: [] });
  const [livePrices, setLivePrices] = useState({});
  const [lastTick, setLastTick] = useState("--:--:--");
  const [timeframe, setTimeframe] = useState("1h");

  const [tradeCost, setTradeCost] = useState(60);
  const [isEditingBalance, setIsEditingBalance] = useState(false);
  const [tempBalance, setTempBalance] = useState(500000);

  const [strategy, setStrategy] = useState("Custom / Multi-Leg Strategy");
  const [expiry, setExpiry] = useState("");
  const [legsBuilder, setLegsBuilder] = useState([{ id: 1, action: 'Sell', type: 'PE', strike: 22000, lots: 0, expiry: '' }]);
  
  const [expandedTrades, setExpandedTrades] = useState(new Set());
  const chartContainerRef = useRef(null);
  const chartInstance = useRef(null);
  const candleSeries = useRef(null);
  const smaSeries = useRef(null);

  // 1. System Boot Sequence
  useEffect(() => {
    const bootSystem = async () => {
      try {
        const sysRes = await fetch(`${API_BASE}/system_status`);
        const sysData = await sysRes.json();
        setHwid(sysData.hwid);
        
        if (!sysData.is_licensed) { setAppState('LICENSE_REQ'); return; }
        if (!sysData.is_setup) { setAppState('CREDS_REQ'); return; }
        
        // Load User Data from local hard drive file
        const userRes = await fetch(`${API_BASE}/user_data`);
        const userData = await userRes.json();
        setBalance(userData.balance || 500000);
        setActiveTrade(userData.active_trade || { status: 'NONE', strategy: '', expiry: '', legs: [], entryTime: '' });
        setTradeHistory(userData.trade_history || []);
        setTempBalance(userData.balance || 500000);
        
        setAppState('READY');
      } catch (e) {
        setTimeout(bootSystem, 2000); // Retry if Python server isn't up yet
      }
    };
    bootSystem();
  }, []);

  // Save to Backend Helper
  const syncToBackend = async (newBalance, newActiveTrade, newHistory) => {
    try {
      await fetch(`${API_BASE}/user_data`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ balance: newBalance, active_trade: newActiveTrade, trade_history: newHistory })
      });
    } catch (e) { console.error("Failed to sync to hard drive."); }
  };

  // Sync Balance edits directly
  useEffect(() => {
    if (appState === 'READY' && !isEditingBalance) {
      syncToBackend(balance, activeTrade, tradeHistory);
    }
  }, [balance]);

  // Chart & Market Initialization
  useEffect(() => {
    if (appState !== 'READY' || activeTab !== 'TERMINAL') return;
    
    let isMounted = true;
    if (!window.LightweightCharts) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/lightweight-charts@4.1.1/dist/lightweight-charts.standalone.production.js';
      script.async = true;
      document.body.appendChild(script);
    }

    const initData = async () => {
      try {
        const mRes = await fetch(`${API_BASE}/market?interval=${timeframe}`);
        const cRes = await fetch(`${API_BASE}/options_chain`);
        if (!mRes.ok || !cRes.ok) throw new Error("API not OK");
        
        const marketRes = await mRes.json();
        const chainRes = await cRes.json();
        
        if (!isMounted) return;
        
        if (marketRes?.spot) setMarket(marketRes);
        if (chainRes?.expiries) {
            setChainData(chainRes);
            if (chainRes.expiries.length > 0 && !expiry) setExpiry(chainRes.expiries[0]);
        }
        setBackendStatus("🟢 Connected");

        if (window.LightweightCharts && chartContainerRef.current && !chartInstance.current) {
          const chart = window.LightweightCharts.createChart(chartContainerRef.current, {
            layout: { textColor: '#1e293b', background: { type: 'solid', color: 'transparent' } },
            grid: { vertLines: { color: '#f1f5f9' }, horzLines: { color: '#f1f5f9' } },
            timeScale: { timeVisible: true }
          });
          const cSeries = chart.addCandlestickSeries({ upColor: '#22c55e', downColor: '#ef4444', borderVisible: false });
          const sSeries = chart.addLineSeries({ color: '#2563eb', lineWidth: 2 });
          
          if (marketRes?.chart_data?.length > 0) cSeries.setData(cleanChartData(marketRes.chart_data));
          if (marketRes?.sma_data?.length > 0) sSeries.setData(cleanChartData(marketRes.sma_data));
          
          chartInstance.current = chart;
          candleSeries.current = cSeries;
          smaSeries.current = sSeries;
        }
      } catch (e) {
        if (isMounted) setBackendStatus("🔴 Backend Offline");
      }
    };
    
    const retryInit = setInterval(() => {
      if (window.LightweightCharts) { initData(); clearInterval(retryInit); }
    }, 500);

    return () => {
      isMounted = false;
      clearInterval(retryInit);
      if (chartInstance.current) { chartInstance.current.remove(); chartInstance.current = null; }
    };
  }, [appState, activeTab, timeframe]);

  // Live Polling Engine
  useEffect(() => {
    if (appState !== 'READY') return;
    const fetchLiveTicks = async () => {
      try {
        const mRes = await fetch(`${API_BASE}/market?interval=${timeframe}`);
        if (!mRes.ok) throw new Error("Network");
        const mData = await mRes.json();
        
        if (mData?.spot) {
            setMarket(mData);
            setLastTick(new Date().toLocaleTimeString());
            setBackendStatus(mData.is_live ? "🟢 Angel Live" : "🟡 Angel Offline");
        }

        if (candleSeries.current && mData?.chart_data?.length > 0 && activeTab === 'TERMINAL') {
           try {
               const cleaned = cleanChartData(mData.chart_data);
               if (cleaned.length > 0) candleSeries.current.update(cleaned[cleaned.length - 1]);
           } catch (chartErr) {}
        }

        const activeLegs = activeTrade?.status === 'OPEN' ? (Array.isArray(activeTrade.legs) ? activeTrade.legs : []) : [];
        const builderLegs = Array.isArray(legsBuilder) ? legsBuilder : [];
        
        let newLivePrices = {};
        
        // Unified polling map for Multi-Expiry / Calendar Spreads
        const allLegsByExpiry = {};
        
        activeLegs.forEach(leg => {
            const legExp = leg.expiry || activeTrade.expiry || expiry;
            if (legExp) {
                if (!allLegsByExpiry[legExp]) allLegsByExpiry[legExp] = [];
                allLegsByExpiry[legExp].push(leg);
            }
        });

        builderLegs.forEach(leg => {
            const legExp = leg.expiry || expiry;
            if (legExp) {
                if (!allLegsByExpiry[legExp]) allLegsByExpiry[legExp] = [];
                allLegsByExpiry[legExp].push(leg);
            }
        });

        for (const [exp, legs] of Object.entries(allLegsByExpiry)) {
           if (legs.length > 0 && exp) {
               // DEDUPLICATION: Remove duplicate strikes to protect Angel One Rate Limits (3/sec)
               const uniqueLegsMap = new Map();
               legs.forEach(l => uniqueLegsMap.set(`${l.strike}_${l.type}`, l));
               const uniqueLegs = Array.from(uniqueLegsMap.values());

               const pRes = await fetch(`${API_BASE}/live_prices`, {
                 method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ expiry: exp, legs: uniqueLegs })
               });
               if (pRes.ok) {
                   const pData = await pRes.json();
                   if (pData?.prices) {
                       Object.entries(pData.prices).forEach(([strikeType, price]) => {
                           newLivePrices[`${exp}_${strikeType}`] = price;
                       });
                   }
               }
           }
        }
        
        if (Object.keys(newLivePrices).length > 0) {
            setLivePrices(prev => {
                const nextState = { ...prev };
                Object.entries(newLivePrices).forEach(([key, price]) => {
                    // ZERO-DROP SHIELD: Ignore fake 0.0 drops caused by API rate limits
                    if (price > 0 || nextState[key] === undefined) {
                        nextState[key] = price;
                    }
                });
                return nextState;
            });
        }
      } catch (e) {}
    };

    const interval = setInterval(fetchLiveTicks, 2000);
    return () => clearInterval(interval);
  }, [legsBuilder, activeTrade, expiry, appState, activeTab, timeframe]);

  // Calculations
  let estMargin = 0; let netCredit = 0;
  
  const mappedLegs = (Array.isArray(legsBuilder) ? legsBuilder : []).map(leg => {
    const legExpiry = leg.expiry || expiry;
    const qty = (leg.lots || 0) * 65; // LOT SIZE UPDATED TO 65
    
    // Look up the price using the exact expiry string!
    const pVal = livePrices[`${legExpiry}_${leg.strike}_${leg.type}`] !== undefined ? livePrices[`${legExpiry}_${leg.strike}_${leg.type}`] : 0.0;
    
    // Calculate DTE uniquely per leg for accurate Calendar Greeks
    const legDte = legExpiry ? Math.max((new Date(legExpiry) - new Date()) / (1000 * 60 * 60 * 24), 0.001) : 1;
    const greeks = calculateGreeks(leg.type, market?.spot || 0, leg.strike, legDte, 0.07, pVal);
    
    if (leg.action === 'Sell') { estMargin += (qty / 25) * 30000 + (pVal * qty * 0.15); netCredit += (pVal * qty); } 
    else { netCredit -= (pVal * qty); }
    return { ...leg, qty, currentPrice: pVal, ...greeks, expiry: legExpiry };
  });

  let spreadWidth = 0; let spotCushion = 0;
  if (mappedLegs.length > 0) {
    const strikes = mappedLegs.map(l => l.strike || 0);
    spreadWidth = Math.max(...strikes) - Math.min(...strikes);
    const sellLegs = mappedLegs.filter(l => l.action === 'Sell');
    if (sellLegs.length > 0 && market?.spot) spotCushion = Math.min(...sellLegs.map(l => Math.abs(market.spot - l.strike)));
  }

  let liveM2M = 0; let activeMarginUsed = 0; let totalActiveDelta = 0; let totalActiveTheta = 0;
  const activeMappedLegs = activeTrade?.status === 'OPEN' ? (Array.isArray(activeTrade.legs) ? activeTrade.legs : []).map(leg => {
    const legExp = leg.expiry || activeTrade.expiry || expiry;
    
    // Look up active position price using its exact expiry string!
    const currentPrice = livePrices[`${legExp}_${leg.strike}_${leg.type}`] !== undefined ? livePrices[`${legExp}_${leg.strike}_${leg.type}`] : (leg.currentPrice || 0);
    
    let legPnl = leg.action === 'Sell' ? (leg.entryPrice - currentPrice) * leg.qty : (currentPrice - leg.entryPrice) * leg.qty;
    liveM2M += legPnl;
    if (leg.action === 'Sell') activeMarginUsed += (leg.qty / 25) * 30000 + (currentPrice * leg.qty * 0.15);
    
    // Calculate active Greeks for live positions table
    const legDte = legExp ? Math.max((new Date(legExp) - new Date()) / (1000 * 60 * 60 * 24), 0.001) : 1;
    const greeks = calculateGreeks(leg.type, market?.spot || 0, leg.strike, legDte, 0.07, currentPrice);

    // Calculate Total Delta
    const legDeltaVal = parseFloat(greeks.delta) || 0;
    const posDelta = leg.action === 'Sell' ? -legDeltaVal * leg.qty : legDeltaVal * leg.qty;
    totalActiveDelta += posDelta;

    // Calculate Total Theta
    const legThetaVal = parseFloat(greeks.theta) || 0;
    const posTheta = leg.action === 'Sell' ? -legThetaVal * leg.qty : legThetaVal * leg.qty;
    totalActiveTheta += posTheta;

    return { ...leg, currentPrice, pnl: legPnl, delta: greeks.delta, theta: greeks.theta, positionDelta: posDelta, positionTheta: posTheta };
  }) : [];

  const availableMargin = balance - activeMarginUsed;
  const historyArray = Array.isArray(tradeHistory) ? tradeHistory : [];
  const totalRealizedPnl = historyArray.reduce((acc, trade) => acc + (trade.pnl || 0), 0);
  const netTotalPnl = totalRealizedPnl + liveM2M;

  const getFormattedDate = () => new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  // Calculate metrics & extract legs specifically for TODAY
  const todayDateString = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const todaysClosedTrades = historyArray.filter(trade => trade.date && trade.date.startsWith(todayDateString));
  
  let todaysRealizedPnl = 0;
  let todaysCosts = 0;
  const todaysClosedLegs = [];

  todaysClosedTrades.forEach(trade => {
    todaysRealizedPnl += (trade.pnl || 0);
    todaysCosts += (trade.cost || 0);
    if (trade.legs) {
      trade.legs.forEach(leg => {
        // Recalculate leg specific P&L
        const legPnl = leg.action === 'Sell' ? (leg.entryPrice - leg.currentPrice) * leg.qty : (leg.currentPrice - leg.entryPrice) * leg.qty;
        // Parse time of exit from trade date "DD MMM YYYY, HH:MM"
        const exitTime = trade.date.includes(',') ? trade.date.split(', ')[1] : '';
        todaysClosedLegs.push({ ...leg, exitPrice: leg.currentPrice, realizedPnl: legPnl, exitTime: exitTime });
      });
    }
  });

  const todaysNetPnl = todaysRealizedPnl + liveM2M;

  // Execution Handlers
  const executeOrder = () => {
    const executionLegs = mappedLegs.filter(l => l.lots > 0).map(l => ({ ...l, entryPrice: l.currentPrice, expiry: l.expiry || expiry }));
    if (executionLegs.length === 0) return alert("Please set at least 1 lot to execute a trade!");
    if (estMargin > availableMargin) return alert("Insufficient Margin!");
    
    const existingLegs = activeTrade.status === 'OPEN' ? activeTrade.legs : [];
    const newActive = {
      status: 'OPEN',
      strategy: activeTrade.status === 'OPEN' ? "Custom / Multi-Leg Strategy" : strategy,
      expiry: activeTrade.status === 'OPEN' ? (activeTrade.expiry || expiry) : expiry,
      legs: [...existingLegs, ...executionLegs],
      entryTime: activeTrade.status === 'OPEN' ? activeTrade.entryTime : getFormattedDate()
    };
    setActiveTrade(newActive);
    syncToBackend(balance, newActive, tradeHistory);
    setLegsBuilder([{ id: Date.now(), action: 'Sell', type: 'PE', strike: (market?.spot || 22000) - ((market?.spot || 22000)%50), lots: 0, expiry: expiry }]);
  };

  const squareOffLeg = (indexToSquareOff) => {
    const legToExit = activeMappedLegs[indexToSquareOff];
    const netRealizedPnl = (legToExit.pnl || 0) - tradeCost;
    
    const newBalance = balance + netRealizedPnl;
    const newHistory = [{ date: getFormattedDate(), strategy: `Partial Exit: ${legToExit.action} ${legToExit.strike} ${legToExit.type}`, pnl: netRealizedPnl, cost: tradeCost, legs: [{ ...legToExit }] }, ...historyArray];
    const remainingLegs = activeTrade.legs.filter((_, i) => i !== indexToSquareOff);
    const newActive = { ...activeTrade, status: remainingLegs.length > 0 ? 'OPEN' : 'NONE', legs: remainingLegs };

    setBalance(newBalance);
    setTradeHistory(newHistory);
    setActiveTrade(newActive);
    syncToBackend(newBalance, newActive, newHistory);
  };

  const squareOffStrategy = () => {
    const totalCost = (activeTrade?.legs?.length || 0) * tradeCost;
    const netLiveM2M = liveM2M - totalCost;
    
    const newBalance = balance + netLiveM2M;
    const newHistory = [{ date: getFormattedDate(), strategy: `Full Exit: ${activeTrade.strategy || "Positions"}`, pnl: netLiveM2M, cost: totalCost, legs: activeMappedLegs.map(l => ({ ...l })) }, ...historyArray];
    const newActive = { status: 'NONE', strategy: '', legs: [], entryTime: '' };

    setBalance(newBalance);
    setTradeHistory(newHistory);
    setActiveTrade(newActive);
    syncToBackend(newBalance, newActive, newHistory);
  };

  const deleteTrade = (indexToRemove) => {
    const tradeToDelete = historyArray[indexToRemove];
    const newBalance = balance - (tradeToDelete?.pnl || 0);
    const newHistory = historyArray.filter((_, i) => i !== indexToRemove);
    
    setBalance(newBalance);
    setTradeHistory(newHistory);
    syncToBackend(newBalance, activeTrade, newHistory);
  };

  const toggleExpandTrade = (index) => {
    setExpandedTrades(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) newSet.delete(index);
      else newSet.add(index);
      return newSet;
    });
  };

  const exportToCSV = () => {
    if (historyArray.length === 0) return alert("No data to export");
    let csvContent = "Date,Time,Strategy,Cost (Rs),Net PnL (Rs),Legs Details\n";
    historyArray.forEach(trade => {
      const [datePart, timePart] = (trade.date || ", ").split(', ');
      let legsStr = "";
      if (trade.legs && trade.legs.length > 0) {
        legsStr = trade.legs.map(l => `${l.action} ${l.strike} ${l.type} (${l.expiry || trade.expiry || "N/A"}) [Qty: ${l.qty/65}, Entry: ${l.entryPrice?.toFixed(2)}, Exit: ${l.currentPrice?.toFixed(2)}]`).join(" | ");
      }
      const safeStrategy = `"${trade.strategy || ""}"`;
      const safeLegs = `"${legsStr}"`;
      csvContent += `${datePart},${timePart},${safeStrategy},${trade.cost || 0},${trade.pnl?.toFixed(2)},${safeLegs}\n`;
    });
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `JaiTrader_TradeBook_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- ANALYTICS DASHBOARD COMPONENT ---
  const renderAnalytics = () => {
    const dailyStats = {};
    historyArray.forEach(t => {
      const dateKey = (t.date || "").split(',')[0].trim();
      if (!dateKey) return;
      if (!dailyStats[dateKey]) dailyStats[dateKey] = { pnl: 0, trades: 0 };
      dailyStats[dateKey].pnl += (t.pnl || 0);
      dailyStats[dateKey].trades += 1;
    });

    const dates = Object.keys(dailyStats);
    const winDays = dates.filter(d => dailyStats[d].pnl >= 0).length;
    const lossDays = dates.length - winDays;

    return (
      <div className="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-sm font-bold text-slate-500 mb-4 flex items-center gap-2"><Target size={16}/> PERFORMANCE METRICS</h3>
            <div className="space-y-4">
              <div>
                <div className="text-xs font-bold text-slate-400">TOTAL REALIZED PROFIT</div>
                <div className={`text-3xl font-extrabold ${totalRealizedPnl >= 0 ? 'text-green-600':'text-red-600'}`}>
                  {totalRealizedPnl >= 0 ? '+':''}₹{totalRealizedPnl.toLocaleString('en-IN', {minimumFractionDigits:2})}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                <div>
                  <div className="text-xs font-bold text-slate-400">WINNING DAYS</div>
                  <div className="text-xl font-bold text-slate-800">{winDays}</div>
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-400">LOSING DAYS</div>
                  <div className="text-xl font-bold text-slate-800">{lossDays}</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-slate-800 p-6 rounded-xl shadow-sm text-white">
            <h3 className="text-sm font-bold text-slate-400 mb-2 flex items-center gap-2"><Award size={16}/> SUBSCRIPTION</h3>
            <div className="text-2xl font-bold mb-1">PRO LICENSE ACTIVE</div>
            <div className="text-xs text-slate-500 font-mono mb-4">HWID: {hwid}</div>
          </div>
        </div>

        <div className="col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-sm font-bold text-slate-500 mb-6 flex items-center gap-2"><Calendar size={16}/> DAILY P&L CALENDAR</h3>
          {dates.length > 0 ? (
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-7 gap-2">
              {dates.map(date => {
                const dayPnl = dailyStats[date].pnl;
                const isWin = dayPnl >= 0;
                return (
                  <div key={date} className={`p-2 rounded-lg border flex flex-col items-center justify-center text-center ${isWin ? 'border-green-100 bg-green-50' : 'border-red-100 bg-red-50'}`}>
                    <div className="text-[10px] font-bold text-slate-500 mb-1">{date}</div>
                    <div className={`text-sm font-extrabold ${isWin ? 'text-green-600':'text-red-600'}`}>
                      {isWin?'+':''}₹{dayPnl.toLocaleString('en-IN', {minimumFractionDigits:0})}
                    </div>
                    <div className="text-[9px] font-bold text-slate-400 mt-1">{dailyStats[date].trades} Trades</div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 font-medium border border-dashed rounded-lg">No trading history to display.</div>
          )}
        </div>
        
        {/* --- RESTORED TRADE BOOK LIST --- */}
        <div className="col-span-1 lg:col-span-3 mt-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold text-slate-500 flex items-center gap-2"><Activity size={16}/> DETAILED TRADE LEDGER</h3>
            <button onClick={exportToCSV} className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 py-1.5 px-3 rounded-md transition-colors border border-blue-200 shadow-sm">
              <Download size={14} /> Export CSV
            </button>
          </div>
          
          {historyArray.length > 0 ? (
            <div className="bg-slate-50 rounded-lg border border-slate-200 divide-y divide-slate-200 max-h-[400px] overflow-y-auto">
              {historyArray.map((trade, i) => (
                <div key={i} className="flex flex-col bg-white hover:bg-slate-50 transition-colors">
                  <div className="flex justify-between items-center p-3 cursor-pointer" onClick={() => toggleExpandTrade(i)}>
                    <div className="flex items-center gap-3">
                      <div className="text-slate-400">{expandedTrades.has(i) ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</div>
                      <div>
                        <div className="font-bold text-sm text-slate-800">{trade.strategy}</div>
                        <div className="text-xs font-medium text-slate-500">{trade.date}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className={`text-right ${((trade.pnl || 0) >= 0) ? 'text-green-600' : 'text-red-600'}`}>
                         <div className="font-bold text-sm">{(trade.pnl || 0) >= 0 ? '+' : ''}₹{(trade.pnl || 0).toLocaleString('en-IN', {minimumFractionDigits:2})}</div>
                         {trade.cost > 0 && <div className="text-[10px] text-slate-400 font-normal">Net of ₹{trade.cost} fees</div>}
                      </div>
                      <button onClick={(e) => { e.stopPropagation(); deleteTrade(i); }} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-100 rounded-md"><Trash2 size={16} /></button>
                    </div>
                  </div>
                  
                  {expandedTrades.has(i) && trade.legs && trade.legs.length > 0 && (
                    <div className="bg-slate-100/50 p-3 border-t border-slate-100 text-xs shadow-inner">
                      <table className="w-full text-left border-collapse">
                        <thead className="text-[10px] font-bold text-slate-500 uppercase border-b border-slate-200">
                          <tr><th className="pb-2">Leg Breakdown</th><th className="pb-2">Qty (Lots)</th><th className="pb-2">Entry Price</th><th className="pb-2">Exit Price</th><th className="pb-2 text-right">Leg P&L</th></tr>
                        </thead>
                        <tbody>
                          {trade.legs.map((l, lIndex) => {
                            const lPnl = l.action === 'Sell' ? (l.entryPrice - l.currentPrice) * l.qty : (l.currentPrice - l.entryPrice) * l.qty;
                            return (
                              <tr key={lIndex} className="border-b border-slate-100 last:border-0">
                                <td className="py-2 font-bold text-slate-700">{l.action} {l.strike} {l.type}<span className="block text-[9px] text-slate-400 font-normal">{l.expiry || trade.expiry}</span></td>
                                <td className="py-2">{l.qty / 65}</td>
                                <td className="py-2">₹{l.entryPrice?.toFixed(2)}</td>
                                <td className="py-2">₹{l.currentPrice?.toFixed(2)}</td>
                                <td className={`py-2 text-right font-bold ${lPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>{lPnl >= 0 ? '+' : ''}₹{lPnl.toLocaleString('en-IN', {minimumFractionDigits:2})}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-sm text-slate-500 bg-slate-50 p-4 rounded border text-center">No completed trades yet.</div>
          )}
        </div>
      </div>
    );
  };

  // --- WIZARD SCREENS ---
  if (appState === 'CHECKING') {
    return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white"><Activity className="animate-spin mr-2"/> Initializing Engine...</div>;
  }

  if (appState === 'LICENSE_REQ') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl max-w-md w-full shadow-2xl text-center">
          <div className="bg-blue-100 p-4 rounded-full inline-block mb-4"><Lock className="text-blue-600" size={32}/></div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Activate Terminal</h2>
          <p className="text-sm text-slate-500 mb-6">Enter your commercial license key to unlock the software.</p>
          
          <div className="bg-slate-50 p-3 rounded border border-slate-200 mb-6">
            <div className="text-[10px] font-bold text-slate-400 mb-1">YOUR HARDWARE ID</div>
            <div className="font-mono text-lg font-bold tracking-wider text-slate-700">{hwid}</div>
          </div>

          <input type="text" id="licenseKey" placeholder="XXXX-XXXX-XXXX-XXXX" className="w-full p-3 border border-slate-300 rounded-lg mb-4 text-center font-bold outline-none focus:border-blue-500" />
          <button onClick={async () => {
            const val = document.getElementById('licenseKey').value;
            const res = await fetch(`${API_BASE}/activate_license`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({key: val}) });
            const data = await res.json();
            if(data.success) window.location.reload();
            else alert(data.message);
          }} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition-colors">Verify & Activate</button>
        </div>
      </div>
    );
  }

  if (appState === 'CREDS_REQ') {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl max-w-md w-full shadow-2xl">
          <div className="text-center mb-6">
            <div className="bg-green-100 p-4 rounded-full inline-block mb-4"><Key className="text-green-600" size={32}/></div>
            <h2 className="text-2xl font-bold text-slate-800">Angel One Link</h2>
            <p className="text-sm text-slate-500">Connect your broker API to stream live data.</p>
          </div>
          <div className="space-y-4">
            <div><label className="text-xs font-bold text-slate-500">CLIENT ID</label><input id="c_id" type="text" className="w-full p-2.5 border rounded-lg bg-slate-50 mt-1" /></div>
            <div><label className="text-xs font-bold text-slate-500">4-DIGIT PIN</label><input id="c_pin" type="password" maxLength="4" className="w-full p-2.5 border rounded-lg bg-slate-50 mt-1" /></div>
            <div><label className="text-xs font-bold text-slate-500">SMART API KEY</label><input id="c_api" type="password" className="w-full p-2.5 border rounded-lg bg-slate-50 mt-1" /></div>
            <div><label className="text-xs font-bold text-slate-500">TOTP SECRET (16 Chars)</label><input id="c_totp" type="password" className="w-full p-2.5 border rounded-lg bg-slate-50 mt-1" /></div>
            <button onClick={async () => {
              const payload = { api_key: document.getElementById('c_api').value, client_id: document.getElementById('c_id').value, pin: document.getElementById('c_pin').value, totp_secret: document.getElementById('c_totp').value };
              const res = await fetch(`${API_BASE}/setup_credentials`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
              const data = await res.json();
              if(data.success) window.location.reload();
              else alert(data.message);
            }} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition-colors mt-2">Connect Broker</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 p-4 font-sans text-slate-900 pb-20">
      {/* HEADER & TABS (overflow-hidden removed to fix P&L breakdown box, replaced with z-40 and relative layering) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-4 relative z-40">
        <div className="flex justify-between items-center p-4">
          <div>
            <div className="flex items-center gap-3">
              <img 
                src="/logo.ico" 
                alt="Jai Trader Bull Logo" 
                className="w-10 h-10 object-contain drop-shadow-md" 
                onError={(e) => { e.target.onerror = null; e.target.src = '/logo.png'; }}
              />
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-extrabold text-slate-800 tracking-tight">JAI TRADER</span>
                <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">v1.4</span>
              </div>
            </div>
            <div className="text-xs font-medium flex items-center gap-1 mt-1">
               <span className={backendStatus.includes('Offline') ? 'text-red-600' : 'text-green-600'}>{backendStatus}</span> 
               | Last Tick: {lastTick}
            </div>
          </div>
          
          <div className="flex gap-8 text-right">
            <div className="flex flex-col items-end">
              <div className="text-xs text-slate-500 font-bold">
                {isEditingBalance ? <span className="text-blue-500">SET BASE BALANCE</span> : "AVAILABLE MARGIN"}
              </div>
              {isEditingBalance ? (
                <div className="flex items-center justify-end mt-0.5">
                  <span className="text-lg font-bold text-slate-400 mr-1">₹</span>
                  <input type="number" autoFocus value={tempBalance} onChange={e => setTempBalance(e.target.value)} onBlur={() => { setBalance(parseFloat(tempBalance) || 0); setIsEditingBalance(false); }} onKeyDown={(e) => { if (e.key === 'Enter') { setBalance(parseFloat(tempBalance) || 0); setIsEditingBalance(false); } }} className="w-28 text-lg font-bold text-right border-b-2 border-blue-500 outline-none bg-blue-50 px-1 rounded-t text-blue-700" />
                </div>
              ) : (
                <div onClick={() => { setTempBalance(balance); setIsEditingBalance(true); }} title="Click to edit account balance" className="text-lg font-bold cursor-pointer hover:text-blue-600 border-b-2 border-transparent hover:border-blue-200 transition-colors">
                  ₹{availableMargin.toLocaleString('en-IN', {minimumFractionDigits: 2})}
                </div>
              )}
            </div>
            
            {/* Header P&L Hover Box - z-[100] ensures it drops down over everything below it */}
            <div className="relative group cursor-pointer z-[100]">
              <div className="text-xs text-slate-500 font-bold flex items-center justify-end gap-1">NET TOTAL P&L <Info size={14} className="text-slate-400" /></div>
              <div className={`text-lg font-bold ${netTotalPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>{netTotalPnl >= 0 ? '+' : ''}₹{netTotalPnl.toLocaleString('en-IN', {minimumFractionDigits: 2})}</div>
              <div className="absolute top-full right-0 mt-2 w-56 bg-slate-800 text-white text-xs rounded-lg p-3 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                <div className="font-bold border-b border-slate-600 pb-1 mb-2 text-slate-300">P&L BREAKDOWN</div>
                <div className="flex justify-between mb-1"><span>Realized:</span><span className={`font-bold ${totalRealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>{totalRealizedPnl >= 0 ? '+' : ''}₹{totalRealizedPnl.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Live M2M:</span><span className={`font-bold ${liveM2M >= 0 ? 'text-green-400' : 'text-red-400'}`}>{liveM2M >= 0 ? '+' : ''}₹{liveM2M.toFixed(2)}</span></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* TABS NAVIGATION (added explicit rounding to bottom corners since overflow-hidden was removed from parent) */}
        <div className="flex border-t border-slate-100">
          <button onClick={() => setActiveTab('TERMINAL')} className={`flex-1 py-3 text-sm font-bold transition-colors rounded-bl-xl ${activeTab === 'TERMINAL' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}>
            <Activity size={16} className="inline mr-2 mb-0.5"/> TRADING TERMINAL
          </button>
          <button onClick={() => setActiveTab('ANALYTICS')} className={`flex-1 py-3 text-sm font-bold transition-colors rounded-br-xl ${activeTab === 'ANALYTICS' ? 'bg-blue-50 text-blue-700 border-b-2 border-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}>
            <BarChart2 size={16} className="inline mr-2 mb-0.5"/> PERFORMANCE ANALYTICS
          </button>
        </div>
      </div>

      {/* --- RENDER ACTIVE TAB --- */}
      {activeTab === 'ANALYTICS' ? renderAnalytics() : (
      <>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-8 flex flex-col gap-4">
            
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">
                  <Activity size={18} className="text-blue-600"/> Market View
                </h3>
                <select value={timeframe} onChange={e => setTimeframe(e.target.value)} className="bg-slate-50 border border-slate-200 text-xs font-bold p-1.5 rounded outline-none cursor-pointer">
                  <option value="1m">1 Min</option>
                  <option value="2m">2 Min</option>
                  <option value="5m">5 Min</option>
                  <option value="15m">15 Min</option>
                  <option value="30m">30 Min</option>
                  <option value="1h">1 Hour</option>
                </select>
              </div>
              
              <div className="relative w-full h-[400px] border border-slate-100 rounded-lg overflow-hidden bg-slate-50">
                <div className="absolute top-3 left-4 z-10 pointer-events-none">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">NIFTY 50</div>
                  <div className="text-2xl font-black text-slate-800 leading-none tracking-tight">₹{(market?.spot || 0).toFixed(2)}</div>
                </div>
                
                <div ref={chartContainerRef} className="w-full h-full"></div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">
                  🛠️ Strategy Legs Setup
                  <span className="text-[10px] font-bold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full ml-1">(1 Lot = 65)</span>
                </h3>
                <button onClick={() => setLegsBuilder(p => [...p, { id: Date.now(), action: 'Buy', type: 'PE', strike: (market?.spot || 22000) - ((market?.spot || 22000)%50), lots: 0, expiry: expiry }])} className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-md text-sm font-semibold transition-colors"><Plus size={16} /> Add Leg</button>
              </div>

              <div className="space-y-3">
                {mappedLegs.map((leg) => (
                  <div key={leg.id} className="flex flex-col xl:flex-row items-center gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-blue-300 transition-colors">
                    
                    <div className="w-full xl:w-[75%] grid grid-cols-12 gap-2">
                      <select className="col-span-4 lg:col-span-2 p-2 border rounded-md text-sm bg-white font-medium outline-none" value={leg.action} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, action: e.target.value} : l))}>
                        <option>Sell</option><option>Buy</option>
                      </select>
                      
                      <select className="col-span-4 lg:col-span-2 p-2 border rounded-md text-sm bg-white font-medium outline-none" value={leg.type} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, type: e.target.value} : l))}>
                        <option>PE</option><option>CE</option>
                      </select>
                      
                      <select className="col-span-4 lg:col-span-3 p-2 border rounded-md text-sm bg-white font-bold text-slate-700 outline-none truncate" value={leg.expiry || expiry} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, expiry: e.target.value} : l))}>
                        {(chainData?.expiries || []).map(exp => <option key={exp} value={exp}>{exp}</option>)}
                      </select>

                      <select className="col-span-6 lg:col-span-3 p-2 border rounded-md text-sm bg-white font-medium outline-none" value={leg.strike} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, strike: parseInt(e.target.value)} : l))}>
                        {(chainData?.strikes || []).map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      
                      <div className="col-span-6 lg:col-span-2 relative">
                        <input type="number" min="0" className="w-full p-2 border rounded-md text-sm font-bold text-center bg-white placeholder-slate-400 focus:border-blue-400 outline-none" value={leg.lots === 0 ? "" : leg.lots} placeholder="Lots" onChange={e => { const val = parseInt(e.target.value, 10); setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, lots: isNaN(val) ? 0 : Math.max(0, val)} : l)); }} />
                      </div>
                    </div>
                    
                    <div className="w-full xl:w-[25%] flex justify-between items-center xl:pl-4 xl:border-l border-slate-200 pt-2 xl:pt-0 border-t xl:border-t-0 mt-2 xl:mt-0">
                      <div>
                        <div className="text-[10px] font-bold text-slate-500 uppercase">Live LTP</div>
                        <div className="text-lg font-bold text-blue-600 leading-tight">₹{(leg.currentPrice || 0).toFixed(2)}</div>
                        <div className="text-[9px] font-bold text-slate-400 mt-0.5 tracking-wide">Δ: {leg.delta} | Θ: {leg.theta} | IV: {leg.iv}%</div>
                      </div>
                      <button onClick={() => setLegsBuilder(p => p.filter(l => l.id !== leg.id))} disabled={mappedLegs.length === 1} className="p-2.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md disabled:opacity-30 transition-colors">
                        <X size={20} />
                      </button>
                    </div>

                  </div>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-4 gap-4">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100"><div className="text-[11px] font-bold text-slate-500 mb-1">{netCredit >= 0 ? 'NET CREDIT' : 'NET DEBIT'}</div><div className={`text-lg font-bold ${netCredit >= 0 ? 'text-green-600' : 'text-red-600'}`}>₹{Math.abs(netCredit).toLocaleString('en-IN', {minimumFractionDigits:2})}</div></div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100"><div className="text-[11px] font-bold text-slate-500 mb-1">TOTAL LEGS</div><div className="text-lg font-bold text-slate-800">{mappedLegs.length} Legs</div></div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100"><div className="text-[11px] font-bold text-slate-500 mb-1">CUSHION / WIDTH</div><div className="text-lg font-bold text-slate-800">{spotCushion.toFixed(0)} <span className="text-sm font-medium text-slate-400">/ {spreadWidth}</span></div></div>
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100"><div className="text-[11px] font-bold text-slate-500 mb-1">MARGIN REQ.</div><div className="text-lg font-bold text-slate-800">₹{estMargin.toLocaleString('en-IN', {minimumFractionDigits:2})}</div></div>
              </div>

              <button onClick={executeOrder} className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg flex justify-center gap-2 transition-colors">
                {activeTrade?.status === 'OPEN' ? '🚀 Execute & Append to Live Position' : '🚀 Execute Market Order'}
              </button>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center gap-2"><TrendingUp size={18} className="text-orange-500"/> Algo Signals ({timeframe})</h3>
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg mb-4">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-1"><Info size={16} className="text-slate-500"/> {market?.algo?.signal || "WAIT"}</div>
                <p className="text-sm text-slate-600 font-medium">{market?.algo?.details}</p>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-2 bg-slate-50 rounded border border-slate-100"><div className="text-[10px] font-bold text-slate-500 mb-1">20 SMA</div><div className="text-sm font-bold text-slate-800">₹{(market?.indicators?.sma20 || 0).toFixed(1)}</div></div>
                <div className="text-center p-2 bg-slate-50 rounded border border-slate-100"><div className="text-[10px] font-bold text-slate-500 mb-1">RSI (14)</div><div className="text-sm font-bold text-slate-800">{(market?.indicators?.rsi || 0).toFixed(1)}</div></div>
                <div className="text-center p-2 bg-slate-50 rounded border border-slate-100"><div className="text-[10px] font-bold text-slate-500 mb-1">RSI SIGNAL</div><div className="text-sm font-bold text-slate-800">{(market?.indicators?.rsi_sig || 0).toFixed(1)}</div></div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center gap-2"><ShieldAlert size={18} className="text-purple-600"/> Configuration</h3>
              <div className="space-y-4">
                <div><label className="text-xs font-bold text-slate-500 mb-1 block">SELECT STRATEGY</label><select className="w-full p-2.5 border rounded-lg bg-slate-50 text-sm font-bold outline-none" value={strategy} onChange={e => setStrategy(e.target.value)}><option>Custom / Multi-Leg Strategy</option><option>Bull Put Spread</option><option>Bear Call Spread</option></select></div>
                <div><label className="text-xs font-bold text-slate-500 mb-1 block">SELECT EXPIRY</label><select className="w-full p-2.5 border rounded-lg bg-slate-50 text-sm font-bold outline-none" value={expiry} onChange={e => setExpiry(e.target.value)}>{(chainData?.expiries || []).map(exp => <option key={exp} value={exp}>{exp}</option>)}</select></div>
                <div className="pt-3 border-t border-slate-100">
                  <label className="text-xs font-bold text-slate-500 mb-1 flex justify-between"><span>BROKERAGE & TAXES</span><span className="text-slate-400 font-normal">per leg (Round Trip)</span></label>
                  <div className="relative"><span className="absolute left-3 top-2.5 text-slate-500 font-bold">₹</span><input type="number" min="0" value={tradeCost} onChange={e => setTradeCost(parseFloat(e.target.value) || 0)} className="w-full p-2.5 pl-8 border rounded-lg bg-slate-50 text-sm font-bold outline-none" /></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-4 border-b pb-3">
            <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">💼 Active & Today's Closed Positions</h3>
            {activeTrade?.status === 'OPEN' && (<button onClick={squareOffStrategy} className="bg-red-600 hover:bg-red-700 text-white font-bold py-1.5 px-4 rounded-md shadow-sm transition-colors text-sm">🟥 SQUARE OFF ENTIRE STRATEGY</button>)}
          </div>
          {(activeTrade?.status === 'OPEN' || todaysClosedLegs.length > 0) ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-slate-100 text-xs font-bold text-slate-500 uppercase">
                  <tr>
                    <th className="p-3 border-y">Instrument</th>
                    <th className="p-3 border-y">Lots <span className="text-[10px] font-normal lowercase opacity-75">(1 lot = 65)</span></th>
                    <th className="p-3 border-y">Entry</th>
                    <th className="p-3 border-y">LTP / Exit</th>
                    <th className="p-3 border-y text-center">Unit Δ | Θ</th>
                    <th className="p-3 text-right border-y">P&L</th>
                    <th className="p-3 text-center border-y">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {/* ACTIVE LEGS */}
                  {activeMappedLegs.map((leg, i) => (
                    <tr key={`active-${i}`} className="border-b hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-bold">{leg.action} {leg.strike} {leg.type}<span className="block text-[10px] text-slate-400 font-normal">{leg.expiry || activeTrade.expiry || expiry}</span></td>
                      <td className="p-3">{leg.qty / 65}</td>
                      <td className="p-3">₹{(leg.entryPrice || 0).toFixed(2)}</td>
                      <td className="p-3 font-bold text-blue-600">₹{(leg.currentPrice || 0).toFixed(2)}</td>
                      <td className="p-3 text-center font-mono font-medium text-slate-600">
                        {leg.delta} <span className="text-slate-300 mx-1">|</span> {leg.theta}
                      </td>
                      <td className={`p-3 text-right font-bold ${leg.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>{leg.pnl >= 0 ? '+' : ''}₹{(leg.pnl || 0).toLocaleString('en-IN', {minimumFractionDigits:2})}</td>
                      <td className="p-3 text-center"><button onClick={() => squareOffLeg(i)} className="text-red-600 border border-red-600 hover:bg-red-600 hover:text-white font-bold px-3 py-1 rounded text-xs transition-colors">✖️ EXIT</button></td>
                    </tr>
                  ))}

                  {/* FADED CLOSED LEGS FOR THE CURRENT DAY */}
                  {todaysClosedLegs.map((leg, i) => (
                    <tr key={`closed-${i}`} className="border-b bg-slate-50 opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0">
                      <td className="p-3 font-bold line-through text-slate-500">{leg.action} {leg.strike} {leg.type}<span className="block text-[10px] text-slate-400 font-normal no-underline">{leg.expiry || expiry}</span></td>
                      <td className="p-3 text-slate-500">{leg.qty / 65}</td>
                      <td className="p-3 text-slate-500">₹{(leg.entryPrice || 0).toFixed(2)}</td>
                      <td className="p-3 text-slate-500">₹{(leg.exitPrice || 0).toFixed(2)} <span className="text-[9px] block">({leg.exitTime})</span></td>
                      <td className="p-3 text-center text-slate-400 font-mono">-</td>
                      <td className={`p-3 text-right font-bold ${leg.realizedPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>{leg.realizedPnl >= 0 ? '+' : ''}₹{(leg.realizedPnl || 0).toLocaleString('en-IN', {minimumFractionDigits:2})}</td>
                      <td className="p-3 text-center"><span className="text-[10px] font-bold text-slate-500 bg-slate-200 px-2 py-1 rounded">CLOSED</span></td>
                    </tr>
                  ))}
                </tbody>
                
                {/* NEW TOTAL DELTA IN OVERALL TOTAL FOOTER */}
                <tfoot className="bg-slate-100 border-t-2 border-slate-200">
                  <tr>
                    <td colSpan="4" className="p-3 text-right font-bold text-slate-700">TODAY'S OVERALL TOTAL (Active + Closed):</td>
                    
                    <td className="p-3 text-center">
                       <div className="text-[10px] text-slate-500 uppercase font-bold leading-none mb-1">Net Δ | Θ</div>
                       <div className="text-sm font-black whitespace-nowrap">
                         <span className={totalActiveDelta > 0 ? 'text-green-600' : totalActiveDelta < 0 ? 'text-red-600' : 'text-slate-700'}>
                           {totalActiveDelta > 0 ? '+' : ''}{totalActiveDelta.toFixed(2)}
                         </span>
                         <span className="text-slate-300 font-normal mx-1">|</span>
                         <span className={totalActiveTheta > 0 ? 'text-green-600' : totalActiveTheta < 0 ? 'text-red-600' : 'text-slate-700'}>
                           {totalActiveTheta > 0 ? '+' : ''}{totalActiveTheta.toFixed(2)}
                         </span>
                       </div>
                    </td>

                    <td className="p-3 text-right relative group cursor-pointer">
                       <div className={`text-lg font-bold ${todaysNetPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                         {todaysNetPnl >= 0 ? '+' : ''}₹{todaysNetPnl.toLocaleString('en-IN', {minimumFractionDigits:2})}
                       </div>
                       
                       {/* Hover Tooltip for Table Footer */}
                       <div className="absolute bottom-full right-0 mb-2 w-64 bg-slate-800 text-white text-xs rounded-lg p-3 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100] text-left">
                          <div className="font-bold border-b border-slate-600 pb-1 mb-2 text-slate-300">TODAY'S P&L BREAKDOWN</div>
                          <div className="flex justify-between mb-1">
                            <span>Today's Realized (Closed):</span>
                            <span className={`font-bold ${todaysRealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              {todaysRealizedPnl >= 0 ? '+' : ''}₹{todaysRealizedPnl.toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between mb-1">
                            <span>Live Unrealized (Open):</span>
                            <span className={`font-bold ${liveM2M >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              {liveM2M >= 0 ? '+' : ''}₹{liveM2M.toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between border-t border-slate-600 pt-1 mt-1">
                            <span>Total Brokerage Paid Today:</span>
                            <span className="font-bold text-orange-400">₹{todaysCosts.toFixed(2)}</span>
                          </div>
                       </div>
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          ) : (<div className="text-center py-6 text-slate-500 font-medium bg-slate-50 rounded-lg border border-dashed">No open or closed positions for today. Use the order window to deploy a strategy.</div>)}
        </div>

      </>
      )}
    </div>
  );
}

export default class AppErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, errorMsg: "" }; }
  static getDerivedStateFromError(error) { return { hasError: true, errorMsg: error.toString() }; }
  render() {
    if (this.state.hasError) return (
      <div className="p-10 bg-slate-900 min-h-screen font-mono flex flex-col items-center justify-center text-center">
        <div className="bg-slate-800 p-8 rounded-xl border border-red-500/30 max-w-2xl"><h2 className="text-2xl font-bold text-red-500 mb-2">Terminal Safety Triggered</h2><button onClick={() => window.location.reload()} className="bg-blue-600 text-white font-bold py-2 px-6 rounded-lg">Reload Terminal</button></div>
      </div>
    );
    return <NiftyStrategyTerminal />;
  }
}