import React, { useState, useEffect, useRef } from 'react';
import { Activity, Plus, X, ShieldAlert, CheckCircle, Clock, Info, TrendingUp, Trash2, ChevronDown, ChevronUp, Download, Zap } from 'lucide-react';

const API_BASE = "http://127.0.0.1:8000/api";

// Pure Math Greek Engine
const erf = (x) => {
  const sign = (x >= 0) ? 1 : -1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
};
const normCdf = (x) => (1.0 + erf(x / Math.sqrt(2.0))) / 2.0;
const normPdf = (x) => Math.exp(-0.5 * x * x) / Math.sqrt(2.0 * Math.PI);

const calculateGreeks = (type, S, K, daysToExpiry, r, marketPrice) => {
  const T = Math.max(daysToExpiry / 365.0, 0.001);
  if (marketPrice <= 0 || S <= 0) return { delta: "0.00", theta: "0.0", iv: "0.0" };

  let high = 2.0, low = 0.0001;
  const cpFlag = type === 'CE' ? 'c' : 'p';
  
  for (let i = 0; i < 30; i++) {
    let mid = (high + low) / 2;
    let d1 = (Math.log(S / K) + (r + 0.5 * mid * mid) * T) / (mid * Math.sqrt(T));
    let d2 = d1 - mid * Math.sqrt(T);
    let price = cpFlag === 'c' 
      ? S * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2)
      : K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
    if (price > marketPrice) high = mid; else low = mid;
  }
  
  let iv = (high + low) / 2;
  let d1 = (Math.log(S / K) + (r + 0.5 * iv * iv) * T) / (iv * Math.sqrt(T));
  let d2 = d1 - iv * Math.sqrt(T);
  
  let delta = cpFlag === 'c' ? normCdf(d1) : normCdf(d1) - 1.0;
  let theta = cpFlag === 'c'
    ? (- (S * iv * normPdf(d1)) / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * normCdf(d2)) / 365
    : (- (S * iv * normPdf(d1)) / (2 * Math.sqrt(T)) + r * K * Math.exp(-r * T) * normCdf(-d2)) / 365;

  return { delta: delta.toFixed(2), theta: theta.toFixed(1), iv: (iv * 100).toFixed(1) };
};

const cleanChartData = (data) => {
  if (!data || !Array.isArray(data)) return [];
  const seen = new Set();
  return data.filter(d => {
      if (seen.has(d.time)) return false;
      seen.add(d.time);
      return true;
  }).sort((a,b) => a.time - b.time);
};

function NiftyStrategyTerminal() {
  const [backendStatus, setBackendStatus] = useState("Connecting...");
  const [market, setMarket] = useState({ spot: 0, is_live: false, indicators: {sma20:0, rsi:0, rsi_sig:0}, algo: {signal:"WAIT", details:""} });
  const [chainData, setChainData] = useState({ expiries: [], strikes: [] });
  const [livePrices, setLivePrices] = useState({});
  const [lastTick, setLastTick] = useState("--:--:--");
  
  const safeJsonParse = (key, defaultVal) => {
    try { const saved = localStorage.getItem(key); return saved ? JSON.parse(saved) : defaultVal; } 
    catch (e) { return defaultVal; }
  };

  const [balance, setBalance] = useState(() => {
    const saved = localStorage.getItem('nifty_balance');
    return saved && !isNaN(parseFloat(saved)) ? parseFloat(saved) : 500000;
  });
  
  const [isEditingBalance, setIsEditingBalance] = useState(false);
  const [tempBalance, setTempBalance] = useState(balance);

  const [tradeCost, setTradeCost] = useState(() => {
    const saved = localStorage.getItem('nifty_trade_cost');
    return saved && !isNaN(parseFloat(saved)) ? parseFloat(saved) : 60;
  });

  const [activeTrade, setActiveTrade] = useState(() => safeJsonParse('nifty_active_trade', { status: 'NONE', strategy: '', expiry: '', legs: [], entryTime: '' }));
  const [tradeHistory, setTradeHistory] = useState(() => safeJsonParse('nifty_trade_history', []));
  
  const [expandedTrades, setExpandedTrades] = useState(new Set());

  useEffect(() => localStorage.setItem('nifty_balance', balance.toString()), [balance]);
  useEffect(() => localStorage.setItem('nifty_trade_cost', tradeCost.toString()), [tradeCost]);
  useEffect(() => localStorage.setItem('nifty_active_trade', JSON.stringify(activeTrade)), [activeTrade]);
  useEffect(() => localStorage.setItem('nifty_trade_history', JSON.stringify(tradeHistory)), [tradeHistory]);

  const [strategy, setStrategy] = useState("Custom / Multi-Leg Strategy");
  const [expiry, setExpiry] = useState("");
  const [legsBuilder, setLegsBuilder] = useState([{ id: 1, action: 'Sell', type: 'PE', strike: 22000, lots: 0 }]);
  
  const chartContainerRef = useRef(null);
  const chartInstance = useRef(null);
  const candleSeries = useRef(null);
  const smaSeries = useRef(null);

  useEffect(() => {
    let isMounted = true;
    
    if (!window.LightweightCharts) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/lightweight-charts@4.1.1/dist/lightweight-charts.standalone.production.js';
      script.async = true;
      document.body.appendChild(script);
    }

    const initData = async () => {
      try {
        const mRes = await fetch(`${API_BASE}/market`);
        const cRes = await fetch(`${API_BASE}/options_chain`);
        
        if (!mRes.ok || !cRes.ok) throw new Error("API Response not OK");
        
        const marketRes = await mRes.json();
        const chainRes = await cRes.json();
        
        if (!isMounted) return;
        
        if (marketRes?.spot) setMarket(marketRes);
        if (chainRes?.expiries) {
            setChainData(chainRes);
            if (chainRes.expiries.length > 0) setExpiry(chainRes.expiries[0]);
        }
        setBackendStatus("🟢 Connected");

        if (window.LightweightCharts && chartContainerRef.current && !chartInstance.current) {
          const chart = window.LightweightCharts.createChart(chartContainerRef.current, {
            layout: { textColor: '#1e293b', background: { type: 'solid', color: 'transparent' } },
            grid: { vertLines: { color: '#f1f5f9' }, horzLines: { color: '#f1f5f9' } },
            timeScale: { timeVisible: true }
          });
          const cSeries = chart.addCandlestickSeries({ upColor: '#22c55e', downColor: '#ef4444', borderVisible: false });
          const sSeries = chart.addLineSeries({ color: '#2563eb', lineWidth: 2 });
          
          if (marketRes?.chart_data?.length > 0) cSeries.setData(cleanChartData(marketRes.chart_data));
          if (marketRes?.sma_data?.length > 0) sSeries.setData(cleanChartData(marketRes.sma_data));
          
          chartInstance.current = chart;
          candleSeries.current = cSeries;
          smaSeries.current = sSeries;
        }
      } catch (e) {
        if (isMounted) setBackendStatus("🔴 Backend Offline (Run api_server.py)");
      }
    };
    
    const retryInit = setInterval(() => {
      if (window.LightweightCharts) {
        initData();
        clearInterval(retryInit);
      }
    }, 500);

    return () => {
      isMounted = false;
      clearInterval(retryInit);
      if (chartInstance.current) {
        chartInstance.current.remove();
        chartInstance.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const fetchLiveTicks = async () => {
      try {
        const mRes = await fetch(`${API_BASE}/market`);
        if (!mRes.ok) throw new Error("Network");
        const mData = await mRes.json();
        
        if (mData?.spot) {
            setMarket(mData);
            setLastTick(new Date().toLocaleTimeString());
            setBackendStatus(mData.is_live ? "🟢 Angel Live" : "🟡 Angel Offline (Yahoo Fallback)");
        }

        if (candleSeries.current && mData?.chart_data?.length > 0) {
           try {
               const cleaned = cleanChartData(mData.chart_data);
               if (cleaned.length > 0) candleSeries.current.update(cleaned[cleaned.length - 1]);
           } catch (chartErr) {}
        }

        const activeLegs = activeTrade?.status === 'OPEN' ? (Array.isArray(activeTrade.legs) ? activeTrade.legs : []) : [];
        const builderLegs = Array.isArray(legsBuilder) ? legsBuilder : [];
        
        let newLivePrices = {};

        const activeByExpiry = {};
        activeLegs.forEach(leg => {
            const legExp = leg.expiry || activeTrade.expiry || expiry;
            if (!activeByExpiry[legExp]) activeByExpiry[legExp] = [];
            activeByExpiry[legExp].push(leg);
        });

        for (const [exp, legs] of Object.entries(activeByExpiry)) {
           if (legs.length > 0 && exp) {
               const pRes = await fetch(`${API_BASE}/live_prices`, {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ expiry: exp, legs: legs })
               });
               if (pRes.ok) {
                   const pData = await pRes.json();
                   if (pData?.prices) {
                       Object.entries(pData.prices).forEach(([strikeType, price]) => {
                           newLivePrices[`${exp}_${strikeType}`] = price;
                       });
                   }
               }
           }
        }

        if (builderLegs.length > 0 && expiry) {
           const pRes = await fetch(`${API_BASE}/live_prices`, {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({ expiry: expiry, legs: builderLegs })
           });
           if (pRes.ok) {
               const pData = await pRes.json();
               if (pData?.prices) {
                   Object.entries(pData.prices).forEach(([strikeType, price]) => {
                       newLivePrices[`${expiry}_${strikeType}`] = price;
                   });
               }
           }
        }
        
        if (Object.keys(newLivePrices).length > 0) {
            setLivePrices(prev => ({...prev, ...newLivePrices}));
        }

      } catch (e) {
         setBackendStatus("🔴 Backend Offline / Waiting for data");
      }
    };

    const interval = setInterval(fetchLiveTicks, 2000);
    return () => clearInterval(interval);
  }, [legsBuilder, activeTrade, expiry]);

  const dte = expiry ? Math.max((new Date(expiry) - new Date()) / (1000 * 60 * 60 * 24), 0.001) : 1;

  let estMargin = 0;
  let netCredit = 0;
  
  const mappedLegs = (Array.isArray(legsBuilder) ? legsBuilder : []).map(leg => {
    const qty = (leg.lots || 0) * 75;
    const pVal = livePrices[`${expiry}_${leg.strike}_${leg.type}`] !== undefined ? livePrices[`${expiry}_${leg.strike}_${leg.type}`] : 0.0;
    const greeks = calculateGreeks(leg.type, market?.spot || 0, leg.strike, dte, 0.07, pVal);
    
    if (leg.action === 'Sell') { 
      estMargin += (qty / 25) * 30000 + (pVal * qty * 0.15); 
      netCredit += (pVal * qty); 
    } 
    else { netCredit -= (pVal * qty); }
    
    return { ...leg, qty, currentPrice: pVal, ...greeks };
  });

  let spreadWidth = 0;
  let spotCushion = 0;
  
  if (mappedLegs.length > 0) {
    const strikes = mappedLegs.map(l => l.strike || 0);
    spreadWidth = Math.max(...strikes) - Math.min(...strikes);
    const sellLegs = mappedLegs.filter(l => l.action === 'Sell');
    if (sellLegs.length > 0 && market?.spot) spotCushion = Math.min(...sellLegs.map(l => Math.abs(market.spot - l.strike)));
  }

  let liveM2M = 0;
  let activeMarginUsed = 0;
  let totalActiveDelta = 0;

  const activeMappedLegs = activeTrade?.status === 'OPEN' ? (Array.isArray(activeTrade.legs) ? activeTrade.legs : []).map(leg => {
    const legExp = leg.expiry || activeTrade.expiry || expiry;
    const currentPrice = livePrices[`${legExp}_${leg.strike}_${leg.type}`] !== undefined ? livePrices[`${legExp}_${leg.strike}_${leg.type}`] : (leg.currentPrice || 0);
    
    let legPnl = leg.action === 'Sell' ? (leg.entryPrice - currentPrice) * leg.qty : (currentPrice - leg.entryPrice) * leg.qty;
    liveM2M += legPnl;
    
    if (leg.action === 'Sell') {
      activeMarginUsed += (leg.qty / 25) * 30000 + (currentPrice * leg.qty * 0.15);
    }

    const legDte = legExp ? Math.max((new Date(legExp) - new Date()) / (1000 * 60 * 60 * 24), 0.001) : 1;
    const greeks = calculateGreeks(leg.type, market?.spot || 0, leg.strike, legDte, 0.07, currentPrice);

    // Calculate Position Delta (Correct mathematical direction)
    const legDeltaVal = parseFloat(greeks.delta) || 0;
    const posDelta = leg.action === 'Sell' ? -legDeltaVal * leg.qty : legDeltaVal * leg.qty;
    totalActiveDelta += posDelta;

    return { ...leg, currentPrice, pnl: legPnl, delta: greeks.delta, positionDelta: posDelta };
  }) : [];

  const availableMargin = balance - activeMarginUsed;
  const historyArray = Array.isArray(tradeHistory) ? tradeHistory : [];
  const totalRealizedPnl = historyArray.reduce((acc, trade) => acc + (trade.pnl || 0), 0);
  const netTotalPnl = totalRealizedPnl + liveM2M;

  // Commercial Feature: Today's Date Filters
  const todayStr = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const todaysTrades = historyArray.filter(t => t.date && t.date.includes(todayStr));
  const todaysRealizedPnl = todaysTrades.reduce((acc, trade) => acc + (trade.pnl || 0), 0);
  const todaysCosts = todaysTrades.reduce((acc, trade) => acc + (trade.cost || 0), 0);
  const todaysNetPnl = todaysRealizedPnl + liveM2M;

  const getFormattedDate = () => {
    return new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const executeOrder = () => {
    const executionLegs = mappedLegs.filter(l => l.lots > 0).map(l => ({ ...l, entryPrice: l.currentPrice, expiry: expiry }));
    if (executionLegs.length === 0) return alert("Please set at least 1 lot to execute a trade!");
    if (estMargin > availableMargin) return alert("Insufficient Margin!");
    
    setActiveTrade(prev => {
      const existingLegs = prev.status === 'OPEN' ? prev.legs : [];
      return {
        status: 'OPEN',
        strategy: prev.status === 'OPEN' ? "Custom / Multi-Leg Strategy" : strategy,
        expiry: prev.status === 'OPEN' ? (prev.expiry || expiry) : expiry,
        legs: [...existingLegs, ...executionLegs],
        entryTime: prev.status === 'OPEN' ? prev.entryTime : getFormattedDate()
      };
    });
    
    setLegsBuilder([{ id: Date.now(), action: 'Sell', type: 'PE', strike: (market?.spot || 22000) - ((market?.spot || 22000)%50), lots: 0 }]);
  };

  const squareOffLeg = (indexToSquareOff) => {
    const legToExit = activeMappedLegs[indexToSquareOff];
    const netRealizedPnl = (legToExit.pnl || 0) - tradeCost;
    const closedLeg = { ...legToExit }; 

    setBalance(prev => prev + netRealizedPnl);
    
    setTradeHistory(prev => [{ 
      date: getFormattedDate(), 
      strategy: `Partial Exit: ${legToExit.action} ${legToExit.strike} ${legToExit.type}`, 
      pnl: netRealizedPnl,
      cost: tradeCost,
      legs: [closedLeg] 
    }, ...(Array.isArray(prev) ? prev : [])]);

    setActiveTrade(prev => {
      const remainingLegs = prev.legs.filter((_, i) => i !== indexToSquareOff);
      return {
        ...prev,
        status: remainingLegs.length > 0 ? 'OPEN' : 'NONE',
        legs: remainingLegs
      };
    });
  };

  const squareOffStrategy = () => {
    const totalCost = (activeTrade?.legs?.length || 0) * tradeCost;
    const netLiveM2M = liveM2M - totalCost;
    const closedLegs = activeMappedLegs.map(l => ({ ...l })); 

    setBalance(prev => prev + netLiveM2M);
    setTradeHistory(prev => [{ 
      date: getFormattedDate(), 
      strategy: `Full Exit: ${activeTrade.strategy || "Positions"}`, 
      pnl: netLiveM2M,
      cost: totalCost,
      legs: closedLegs 
    }, ...(Array.isArray(prev) ? prev : [])]);
    
    setActiveTrade({ status: 'NONE', strategy: '', legs: [], entryTime: '' });
  };

  const deleteTrade = (indexToRemove) => {
    const tradeToDelete = historyArray[indexToRemove];
    if(tradeToDelete) setBalance(prev => prev - (tradeToDelete.pnl || 0));
    setTradeHistory(prev => (Array.isArray(prev) ? prev : []).filter((_, i) => i !== indexToRemove));
  };

  const toggleExpandTrade = (index) => {
    setExpandedTrades(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) newSet.delete(index);
      else newSet.add(index);
      return newSet;
    });
  };

  const exportToCSV = () => {
    if (historyArray.length === 0) return alert("No data to export");
    
    let csvContent = "Date,Time,Strategy,Cost (Rs),Net PnL (Rs),Legs Details\n";
    historyArray.forEach(trade => {
      const [datePart, timePart] = (trade.date || ", ").split(', ');
      let legsStr = "";
      if (trade.legs && trade.legs.length > 0) {
        legsStr = trade.legs.map(l => `${l.action} ${l.strike} ${l.type} (${l.expiry || trade.expiry || "N/A"}) [Qty: ${l.qty/75}, Entry: ${l.entryPrice?.toFixed(2)}, Exit: ${l.currentPrice?.toFixed(2)}]`).join(" | ");
      }
      const safeStrategy = `"${trade.strategy || ""}"`;
      const safeLegs = `"${legsStr}"`;
      csvContent += `${datePart},${timePart},${safeStrategy},${trade.cost || 0},${trade.pnl?.toFixed(2)},${safeLegs}\n`;
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Nifty_TradeBook_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-100 p-4 font-sans text-slate-900 pb-20">
      
      {/* HEADER (NEW LOGO & COMMERCIAL STYLING) */}
      <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-4">
        <div className="flex items-center gap-4">
          <div className="bg-blue-600 p-2.5 rounded-xl shadow-md shadow-blue-200">
            <Zap size={28} className="text-white fill-white/20" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-800 tracking-tight leading-none mb-1">JAI TRADER</div>
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              <span className={backendStatus.includes('Offline') ? 'text-red-600' : 'text-green-600'}>
                {backendStatus}
              </span> 
              | Last Tick: {lastTick}
            </div>
          </div>
        </div>

        <div className="flex gap-8 text-right">
          <div className="flex flex-col items-end">
            <div className="text-xs text-slate-500 font-bold">
              {isEditingBalance ? <span className="text-blue-500">SET BASE BALANCE</span> : "AVAILABLE MARGIN"}
            </div>
            {isEditingBalance ? (
              <div className="flex items-center justify-end mt-0.5">
                <span className="text-lg font-bold text-slate-400 mr-1">₹</span>
                <input
                  type="number"
                  autoFocus
                  value={tempBalance}
                  onChange={e => setTempBalance(e.target.value)}
                  onBlur={() => {
                    setBalance(parseFloat(tempBalance) || 0);
                    setIsEditingBalance(false);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      setBalance(parseFloat(tempBalance) || 0);
                      setIsEditingBalance(false);
                    }
                  }}
                  className="w-28 text-lg font-bold text-right border-b-2 border-blue-500 outline-none bg-blue-50 px-1 rounded-t text-blue-700"
                />
              </div>
            ) : (
              <div 
                onClick={() => {
                  setTempBalance(balance);
                  setIsEditingBalance(true);
                }}
                title="Click to edit account balance"
                className="text-lg font-bold cursor-pointer hover:text-blue-600 border-b-2 border-transparent hover:border-blue-200 transition-colors"
              >
                ₹{availableMargin.toLocaleString('en-IN', {minimumFractionDigits: 2})}
              </div>
            )}
          </div>
          
          <div className="relative group cursor-pointer z-50">
            <div className="text-xs text-slate-500 font-bold flex items-center justify-end gap-1">
              NET TOTAL P&L <Info size={14} className="text-slate-400" />
            </div>
            <div className={`text-lg font-bold ${netTotalPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {netTotalPnl >= 0 ? '+' : ''}₹{netTotalPnl.toLocaleString('en-IN', {minimumFractionDigits: 2})}
            </div>
            
            <div className="absolute top-full right-0 mt-2 w-56 bg-slate-800 text-white text-xs rounded-lg p-3 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              <div className="font-bold border-b border-slate-600 pb-1 mb-2 text-slate-300">P&L BREAKDOWN</div>
              <div className="flex justify-between mb-1">
                <span>Realized (Booked):</span>
                <span className={`font-bold ${totalRealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {totalRealizedPnl >= 0 ? '+' : ''}₹{totalRealizedPnl.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Unrealized (Live M2M):</span>
                <span className={`font-bold ${liveM2M >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {liveM2M >= 0 ? '+' : ''}₹{liveM2M.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8 flex flex-col gap-4">
          
          {/* CHART BOX (WITH SPOT PRICE OVERLAY) */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 relative">
            <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Activity size={18} className="text-blue-600"/> Market View (Live React Sync)
            </h3>
            
            <div className="relative w-full h-[400px] border border-slate-100 rounded-lg bg-slate-50">
              
              {/* NEW: SPOT PRICE CHART OVERLAY */}
              <div className="absolute top-4 left-4 z-10 bg-white/90 backdrop-blur-sm shadow-md border border-slate-200 rounded-lg p-3 pointer-events-none flex flex-col min-w-[120px]">
                 <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-0.5">NIFTY 50</span>
                 <span className="text-2xl font-black text-slate-800 leading-none">₹{(market?.spot || 0).toFixed(2)}</span>
              </div>
              
              {/* Lightweight Chart Container */}
              <div ref={chartContainerRef} className="w-full h-full rounded-lg overflow-hidden"></div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">🛠️ Strategy Legs Setup</h3>
              <button onClick={() => setLegsBuilder(p => [...(Array.isArray(p)?p:[]), { id: Date.now(), action: 'Buy', type: 'PE', strike: (market?.spot || 22000) - ((market?.spot || 22000)%50), lots: 0 }])} className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-md text-sm font-semibold transition-colors">
                <Plus size={16} /> Add Leg
              </button>
            </div>

            <div className="space-y-3">
              {mappedLegs.map((leg) => (
                <div key={leg.id} className="flex items-center gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-blue-300">
                  <div className="flex-1 grid grid-cols-4 gap-3">
                    <select className="p-2 border rounded-md text-sm" value={leg.action} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, action: e.target.value} : l))}>
                      <option>Sell</option><option>Buy</option>
                    </select>
                    <select className="p-2 border rounded-md text-sm" value={leg.type} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, type: e.target.value} : l))}>
                      <option>PE</option><option>CE</option>
                    </select>
                    <select className="p-2 border rounded-md text-sm" value={leg.strike} onChange={e => setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, strike: parseInt(e.target.value)} : l))}>
                      {(chainData?.strikes || []).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <input 
                      type="number" 
                      min="0" 
                      className="p-2 border rounded-md text-sm font-bold text-center placeholder-slate-400 focus:border-blue-400 focus:bg-white transition-colors" 
                      value={leg.lots === 0 ? "" : leg.lots} 
                      placeholder="0"
                      onChange={e => {
                        const val = parseInt(e.target.value, 10);
                        setLegsBuilder(p => p.map(l => l.id === leg.id ? {...l, lots: isNaN(val) ? 0 : Math.max(0, val)} : l));
                      }} 
                    />
                  </div>
                  <div className="flex-1 flex justify-between items-center pl-4 border-l border-slate-200">
                    <div>
                      <div className="text-xs font-bold text-slate-500">LIVE LTP</div>
                      <div className="text-lg font-bold text-blue-600">₹{(leg.currentPrice || 0).toFixed(2)}</div>
                      <div className="text-[10px] font-bold text-slate-400 mt-0.5">Δ: {leg.delta} | Θ: {leg.theta} | IV: {leg.iv}%</div>
                    </div>
                    <button onClick={() => setLegsBuilder(p => p.filter(l => l.id !== leg.id))} disabled={mappedLegs.length === 1} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md disabled:opacity-30"><X size={20} /></button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200 grid grid-cols-4 gap-4">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500 mb-1">{netCredit >= 0 ? 'NET CREDIT' : 'NET DEBIT'}</div>
                <div className={`text-lg font-bold ${netCredit >= 0 ? 'text-green-600' : 'text-red-600'}`}>₹{Math.abs(netCredit).toLocaleString('en-IN', {minimumFractionDigits:2})}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500 mb-1">TOTAL LEGS</div>
                <div className="text-lg font-bold text-slate-800">{mappedLegs.length} Legs</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500 mb-1">CUSHION / WIDTH</div>
                <div className="text-lg font-bold text-slate-800">{spotCushion.toFixed(0)} <span className="text-sm font-medium text-slate-400">/ {spreadWidth}</span></div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500 mb-1">MARGIN REQ.</div>
                <div className="text-lg font-bold text-slate-800">₹{estMargin.toLocaleString('en-IN', {minimumFractionDigits:2})}</div>
              </div>
            </div>

            <button onClick={executeOrder} className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg flex justify-center gap-2">
              {activeTrade?.status === 'OPEN' ? '🚀 Execute & Append to Live Position' : '🚀 Execute Market Order'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center gap-2"><TrendingUp size={18} className="text-orange-500"/> Algo Signals</h3>
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg mb-4">
              <div className="flex items-center gap-2 text-slate-800 font-bold mb-1"><Info size={16} className="text-slate-500"/> {market?.algo?.signal || "WAIT"}</div>
              <p className="text-sm text-slate-600 font-medium">{market?.algo?.details || "Market evaluation pending."}</p>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-2 bg-slate-50 rounded border border-slate-100">
                <div className="text-[10px] font-bold text-slate-500 mb-1">20 SMA</div>
                <div className="text-sm font-bold text-slate-800">₹{(market?.indicators?.sma20 || 0).toFixed(1)}</div>
              </div>
              <div className="text-center p-2 bg-slate-50 rounded border border-slate-100">
                <div className="text-[10px] font-bold text-slate-500 mb-1">RSI (14)</div>
                <div className="text-sm font-bold text-slate-800">{(market?.indicators?.rsi || 0).toFixed(1)}</div>
              </div>
              <div className="text-center p-2 bg-slate-50 rounded border border-slate-100">
                <div className="text-[10px] font-bold text-slate-500 mb-1">RSI SIGNAL</div>
                <div className="text-sm font-bold text-slate-800">{(market?.indicators?.rsi_sig || 0).toFixed(1)}</div>
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center gap-2"><ShieldAlert size={18} className="text-purple-600"/> Configuration & Settings</h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 mb-1 block">SELECT STRATEGY</label>
                <select className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50 text-sm font-bold outline-none" value={strategy} onChange={e => setStrategy(e.target.value)}>
                  <option>Custom / Multi-Leg Strategy</option><option>Bull Put Spread</option><option>Bear Call Spread</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-slate-500 mb-1 block">SELECT EXPIRY</label>
                <select className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50 text-sm font-bold outline-none" value={expiry} onChange={e => setExpiry(e.target.value)}>
                  {(chainData?.expiries || []).map(exp => <option key={exp} value={exp}>{exp}</option>)}
                </select>
              </div>
              
              <div className="pt-3 border-t border-slate-100">
                <label className="text-xs font-bold text-slate-500 mb-1 flex justify-between">
                  <span>BROKERAGE & TAXES</span>
                  <span className="text-slate-400 font-normal">per leg (Round Trip)</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-500 font-bold">₹</span>
                  <input 
                    type="number" 
                    min="0" 
                    value={tradeCost} 
                    onChange={e => setTradeCost(parseFloat(e.target.value) || 0)} 
                    className="w-full p-2.5 pl-8 border border-slate-200 rounded-lg bg-slate-50 text-sm font-bold outline-none transition-colors focus:border-blue-400" 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
        
        {/* ACTIVE POSITIONS HEADER (NEW TOTAL DELTA BADGE) */}
        <div className="flex justify-between items-center mb-4 border-b pb-3">
          <div className="flex items-center gap-6">
            <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">💼 Active Positions & Live M2M</h3>
            
            {/* NEW: TOTAL NET DELTA BADGE */}
            {activeTrade?.status === 'OPEN' && (
              <div className="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg flex flex-col shadow-sm">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider leading-tight">Total Net Delta</span>
                <span className={`text-sm font-black leading-tight ${totalActiveDelta > 0 ? 'text-green-600' : totalActiveDelta < 0 ? 'text-red-600' : 'text-slate-700'}`}>
                  {totalActiveDelta > 0 ? '+' : ''}{totalActiveDelta.toFixed(2)}
                </span>
              </div>
            )}
          </div>
          
          {activeTrade?.status === 'OPEN' && (
            <button onClick={squareOffStrategy} className="bg-red-600 hover:bg-red-700 text-white font-bold py-1.5 px-4 rounded-md shadow-sm transition-colors text-sm">
              🟥 SQUARE OFF ENTIRE STRATEGY
            </button>
          )}
        </div>
        
        {activeTrade?.status === 'OPEN' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-slate-100 text-xs font-bold text-slate-500 uppercase">
                <tr>
                  <th className="p-3 border-y">Instrument</th>
                  <th className="p-3 border-y">Lots <span className="text-[10px] font-normal lowercase opacity-75">(1 lot = 75)</span></th>
                  <th className="p-3 border-y">Entry</th>
                  <th className="p-3 border-y">LTP</th>
                  <th className="p-3 border-y text-center">Unit Delta</th>
                  <th className="p-3 text-right border-y">Live P&L</th>
                  <th className="p-3 text-center border-y">Action</th>
                </tr>
              </thead>
              <tbody>
                {activeMappedLegs.map((leg, i) => (
                  <tr key={i} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="p-3 font-bold">
                      {leg.action} {leg.strike} {leg.type}
                      <span className="block text-[10px] text-slate-400 font-normal">{leg.expiry || activeTrade.expiry || expiry}</span>
                    </td>
                    <td className="p-3">{leg.qty / 75}</td>
                    <td className="p-3">₹{(leg.entryPrice || 0).toFixed(2)}</td>
                    <td className="p-3 font-bold text-blue-600">₹{(leg.currentPrice || 0).toFixed(2)}</td>
                    <td className="p-3 text-center font-mono text-slate-600">{leg.delta}</td>
                    <td className={`p-3 text-right font-bold ${leg.pnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {leg.pnl >= 0 ? '+' : ''}₹{(leg.pnl || 0).toLocaleString('en-IN', {minimumFractionDigits:2})}
                    </td>
                    <td className="p-3 text-center">
                      <button 
                        onClick={() => squareOffLeg(i)} 
                        className="text-red-600 hover:text-white border border-red-600 hover:bg-red-600 font-bold px-3 py-1 rounded transition-all text-xs"
                      >
                        ✖️ EXIT
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              
              {/* RESTORED COMMERCIAL FEATURE: TODAY'S OVERALL TOTAL FOOTER */}
              <tfoot className="bg-slate-100 border-t-2 border-slate-200">
                <tr>
                  <td colSpan="5" className="p-3 text-right font-bold text-slate-700">TODAY'S OVERALL TOTAL (Active + Closed):</td>
                  <td className="p-3 text-right relative group cursor-pointer">
                     <div className={`text-lg font-bold ${todaysNetPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                       {todaysNetPnl >= 0 ? '+' : ''}₹{todaysNetPnl.toLocaleString('en-IN', {minimumFractionDigits:2})}
                     </div>
                     
                     <div className="absolute bottom-full right-0 mb-2 w-64 bg-slate-800 text-white text-xs rounded-lg p-3 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 text-left">
                        <div className="font-bold border-b border-slate-600 pb-1 mb-2 text-slate-300">TODAY'S P&L BREAKDOWN</div>
                        <div className="flex justify-between mb-1">
                          <span>Today's Realized (Closed):</span>
                          <span className={`font-bold ${todaysRealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {todaysRealizedPnl >= 0 ? '+' : ''}₹{todaysRealizedPnl.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between mb-1">
                          <span>Live Unrealized (Open):</span>
                          <span className={`font-bold ${liveM2M >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {liveM2M >= 0 ? '+' : ''}₹{liveM2M.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between border-t border-slate-600 pt-1 mt-1">
                          <span>Total Brokerage Paid Today:</span>
                          <span className="font-bold text-orange-400">₹{todaysCosts.toFixed(2)}</span>
                        </div>
                     </div>
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <div className="text-center py-6 text-slate-500 font-medium bg-slate-50 rounded-lg border border-dashed">No open positions. Use the order window to deploy a strategy.</div>
        )}

        <div className="mt-8 pt-4 border-t border-slate-200">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-4">
              <h4 className="text-sm font-bold text-slate-800">📒 Trade Book (Completed Trades)</h4>
              <button 
                onClick={exportToCSV} 
                className="flex items-center gap-1 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 py-1.5 px-3 rounded-md transition-colors border border-blue-200 shadow-sm"
              >
                <Download size={14} /> Export CSV
              </button>
            </div>
          </div>
          
          {historyArray.length > 0 ? (
            <div className="bg-slate-50 rounded-lg border border-slate-200 divide-y divide-slate-200 max-h-[350px] overflow-y-auto">
              {historyArray.map((trade, i) => (
                <div key={i} className="flex flex-col bg-white hover:bg-slate-50 transition-colors">
                  
                  <div 
                    className="flex justify-between items-center p-3 cursor-pointer"
                    onClick={() => toggleExpandTrade(i)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-slate-400">
                        {expandedTrades.has(i) ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-800">{trade.strategy}</div>
                        <div className="text-xs font-medium text-slate-500">{trade.date}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className={`text-right ${((trade.pnl || 0) >= 0) ? 'text-green-600' : 'text-red-600'}`}>
                         <div className="font-bold text-sm">
                           {(trade.pnl || 0) >= 0 ? '+' : ''}₹{(trade.pnl || 0).toLocaleString('en-IN', {minimumFractionDigits:2})}
                         </div>
                         {trade.cost > 0 && (
                           <div className="text-[10px] text-slate-400 font-normal">
                             Net of ₹{trade.cost} fees
                           </div>
                         )}
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); deleteTrade(i); }} 
                        title="Delete this trade" 
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-100 rounded-md transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  
                  {expandedTrades.has(i) && trade.legs && trade.legs.length > 0 && (
                    <div className="bg-slate-100/50 p-3 border-t border-slate-100 text-xs shadow-inner">
                      <table className="w-full text-left border-collapse">
                        <thead className="text-[10px] font-bold text-slate-500 uppercase border-b border-slate-200">
                          <tr>
                            <th className="pb-2">Leg Breakdown</th>
                            <th className="pb-2">Qty (Lots)</th>
                            <th className="pb-2">Entry Price</th>
                            <th className="pb-2">Exit Price</th>
                            <th className="pb-2 text-right">Leg P&L</th>
                          </tr>
                        </thead>
                        <tbody>
                          {trade.legs.map((l, lIndex) => {
                            const lPnl = l.action === 'Sell' ? (l.entryPrice - l.currentPrice) * l.qty : (l.currentPrice - l.entryPrice) * l.qty;
                            return (
                              <tr key={lIndex} className="border-b border-slate-100 last:border-0">
                                <td className="py-2 font-bold text-slate-700">
                                  {l.action} {l.strike} {l.type}
                                  <span className="block text-[9px] text-slate-400 font-normal">{l.expiry || trade.expiry || expiry}</span>
                                </td>
                                <td className="py-2">{l.qty / 75}</td>
                                <td className="py-2">₹{l.entryPrice?.toFixed(2)}</td>
                                <td className="py-2">₹{l.currentPrice?.toFixed(2)}</td>
                                <td className={`py-2 text-right font-bold ${lPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                  {lPnl >= 0 ? '+' : ''}₹{lPnl.toLocaleString('en-IN', {minimumFractionDigits:2})}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}

                </div>
              ))}
            </div>
          ) : (
             <div className="text-sm text-slate-500 bg-slate-50 p-4 rounded border text-center">No completed trades yet.</div>
          )}
        </div>
      </div>
      
      {/* RESTORED COMMERCIAL FEATURE: VERSION BADGE (UPDATED TO v1.2) */}
      <div className="fixed bottom-4 right-5 text-[11px] font-bold text-slate-400 bg-white/70 px-2.5 py-1 rounded shadow-sm backdrop-blur-md border border-slate-200 pointer-events-none z-50">
         v2.1
      </div>
    </div>
  );
}

export default class AppErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, errorMsg: "" }; }
  static getDerivedStateFromError(error) { return { hasError: true, errorMsg: error.toString() }; }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-10 bg-slate-900 min-h-screen font-mono flex flex-col items-center justify-center text-center">
          <div className="bg-slate-800 p-8 rounded-xl border border-red-500/30 max-w-2xl">
            <h2 className="text-2xl font-bold text-red-500 mb-2">Terminal Safety Triggered</h2>
            <p className="text-slate-400 mb-6">The React UI intercepted a fatal data error (likely a duplicate timestamp from Yahoo Finance) and halted to prevent memory leakage.</p>
            <div className="bg-black p-4 rounded text-sm text-red-400 overflow-auto text-left mb-6">{this.state.errorMsg}</div>
            <button onClick={() => window.location.reload()} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg">Clear Memory & Reload Terminal</button>
          </div>
        </div>
      );
    }
    return <NiftyStrategyTerminal />;
  }
}