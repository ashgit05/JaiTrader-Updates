from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import yfinance as yf
import pandas as pd
import numpy as np 
import datetime
import pyotp
import requests
import math
from SmartApi import SmartConnect
import uvicorn
import logging
import os
import json
import time
import uuid
import hashlib
import jwt 
import gc 

logging.basicConfig(level=logging.INFO)

app = FastAPI()
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

# =================================================================
# 🔴 CRITICAL: THE SECRET KEY 🔴
# This must perfectly match the key in your license_master.py
# =================================================================
SECRET_KEY = "NIFTY_PRO_SUPER_SECRET_KEY_2026_!@#$"

# ==========================================
# COMMERCIAL DATA STORAGE & HARDWARE LOCK
# ==========================================
CONFIG_FILE = "system_config.json"
DATA_FILE = "user_data.json"

raw_hwid = str(uuid.getnode()).encode()
HWID = hashlib.sha256(raw_hwid).hexdigest()[:12].upper()

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f: return json.load(f)
    return {"is_licensed": False, "license_key": None, "angel_creds": None}

def save_config(data):
    with open(CONFIG_FILE, "w") as f: json.dump(data, f)

def load_user_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f: 
            data = json.load(f)
            
        if "balances" not in data:
            old_balance = data.get("balance", 500000)
            old_trade = data.get("active_trade", {"status": "NONE", "strategy": "", "legs": [], "entryTime": ""})
            old_history = data.get("trade_history", [])
            migrated = {
                "balances": {"MONTHLY": old_balance, "WEEKLY": 500000},
                "active_trades": {"MONTHLY": old_trade, "WEEKLY": {"status": "NONE", "strategy": "", "legs": [], "entryTime": ""}},
                "trade_histories": {"MONTHLY": old_history, "WEEKLY": []}
            }
            save_user_data(migrated)
            return migrated
        return data
        
    return {
        "balances": {"MONTHLY": 500000, "WEEKLY": 500000}, 
        "active_trades": {
            "MONTHLY": {"status": "NONE", "strategy": "", "legs": [], "entryTime": ""},
            "WEEKLY": {"status": "NONE", "strategy": "", "legs": [], "entryTime": ""}
        }, 
        "trade_histories": {"MONTHLY": [], "WEEKLY": []}
    }

def save_user_data(data):
    with open(DATA_FILE, "w") as f: json.dump(data, f)

config = load_config()
angel_session = None
opts_df = pd.DataFrame()
market_cache = {"data": None, "last_fetch": None, "interval": "1h"}

# ==========================================
# ANGEL ONE INITIALIZATION
# ==========================================
def init_angel():
    global angel_session, config
    creds = config.get("angel_creds")
    if not creds: return False
    
    try:
        angel = SmartConnect(api_key=creds["api_key"])
        totp = pyotp.TOTP(creds["totp_secret"]).now()
        data = angel.generateSession(creds["client_id"], creds["pin"], totp)
        if data and data.get('status'):
            angel_session = angel
            logging.info("Angel One Commercial Session Authenticated!")
            return True
    except Exception as e:
        logging.error(f"Angel Login Failed: {e}")
    return False

def load_instruments():
    global opts_df
    try:
        scrip_file = "scrip_master_cache.json"
        data = None
        if os.path.exists(scrip_file) and (time.time() - os.path.getmtime(scrip_file)) < 86400:
            with open(scrip_file, 'r') as f: data = json.load(f)
        else:
            url = "https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
            res = requests.get(url, timeout=30)
            data = res.json()
            with open(scrip_file, 'w') as f: json.dump(data, f)
        
        df = pd.DataFrame(data)
        nifty_opts = df[(df['name'] == 'NIFTY') & (df['exch_seg'] == 'NFO') & (df['instrumenttype'] == 'OPTIDX')].copy()
        nifty_opts['expiry_dt'] = pd.to_datetime(nifty_opts['expiry'])
        nifty_opts['strike_price'] = (nifty_opts['strike'].astype(float) / 100).astype(int)
        nifty_opts = nifty_opts[nifty_opts['expiry_dt'] >= pd.Timestamp.now().normalize()]
        opts_df = nifty_opts.sort_values('expiry_dt')
    except Exception as e:
        logging.error(f"Failed to load instruments: {e}")

def verify_active_license():
    global config
    if not config.get("license_key"):
        config["is_licensed"] = False
        return False
        
    try:
        payload = jwt.decode(config["license_key"], SECRET_KEY, algorithms=["HS256"])
        if payload["hwid"] != HWID:
            config["is_licensed"] = False
            return False
        
        config["is_licensed"] = True
        return True
    except jwt.ExpiredSignatureError:
        logging.error("License has expired!")
        config["is_licensed"] = False
        return False
    except jwt.InvalidTokenError:
        logging.error("License signature is invalid or tampered with!")
        config["is_licensed"] = False
        return False

@app.on_event("startup")
def startup_event():
    is_valid = verify_active_license()
    save_config(config) 
    
    if is_valid and config["angel_creds"]:
        init_angel()
    load_instruments()

# ==========================================
# SYSTEM SETUP & LICENSE ENDPOINTS
# ==========================================
@app.get("/api/system_status")
def get_system_status():
    verify_active_license() 
    return {
        "hwid": HWID,
        "is_licensed": config["is_licensed"],
        "is_setup": config["angel_creds"] is not None
    }

class LicenseReq(BaseModel):
    key: str

@app.post("/api/activate_license")
def activate_license(req: LicenseReq):
    global config
    try:
        payload = jwt.decode(req.key.strip(), SECRET_KEY, algorithms=["HS256"])
        
        if payload["hwid"] != HWID:
            return {"success": False, "message": "This license key is locked to a different computer."}
            
        config["is_licensed"] = True
        config["license_key"] = req.key.strip()
        save_config(config)
        return {"success": True}
        
    except jwt.ExpiredSignatureError:
        return {"success": False, "message": "This license key has expired."}
    except jwt.InvalidTokenError:
        return {"success": False, "message": "Invalid or tampered license key."}
    except Exception as e:
        return {"success": False, "message": str(e)}

class CredsReq(BaseModel):
    api_key: str
    client_id: str
    pin: str
    totp_secret: str

@app.post("/api/setup_credentials")
def setup_credentials(req: CredsReq):
    global config
    config["angel_creds"] = req.dict()
    save_config(config)
    success = init_angel()
    if not success:
        config["angel_creds"] = None
        save_config(config)
        return {"success": False, "message": "Invalid Angel One Credentials. Check your TOTP or API key."}
    return {"success": True}

# ==========================================
# LOCAL DATABASE ENDPOINTS
# ==========================================
@app.get("/api/user_data")
def get_user_data():
    return load_user_data()

class UserDataReq(BaseModel):
    balances: dict
    active_trades: dict
    trade_histories: dict

@app.post("/api/user_data")
def update_user_data(req: UserDataReq):
    save_user_data(req.dict())
    return {"success": True}

# ==========================================
# SUPERTREND ALGORITHM
# ==========================================
def calc_supertrend(df, length, multiplier):
    high = df['High']
    low = df['Low']
    close = df['Close']
    
    tr1 = pd.DataFrame(high - low)
    tr2 = pd.DataFrame(abs(high - close.shift(1)))
    tr3 = pd.DataFrame(abs(low - close.shift(1)))
    frames = [tr1, tr2, tr3]
    tr = pd.concat(frames, axis=1, join='inner').max(axis=1)
    
    atr = tr.ewm(alpha=1/length, adjust=False).mean()
    hl2 = (high + low) / 2
    final_upperband = hl2 + (multiplier * atr)
    final_lowerband = hl2 - (multiplier * atr)
    supertrend = [True] * len(df)
    
    for i in range(1, len(df.index)):
        curr, prev = i, i-1
        if close.iloc[curr] > final_upperband.iloc[prev]:
            supertrend[curr] = True
        elif close.iloc[curr] < final_lowerband.iloc[prev]:
            supertrend[curr] = False
        else:
            supertrend[curr] = supertrend[prev]
            if supertrend[curr] == True and final_lowerband.iloc[curr] < final_lowerband.iloc[prev]:
                final_lowerband.iloc[curr] = final_lowerband.iloc[prev]
            if supertrend[curr] == False and final_upperband.iloc[curr] > final_upperband.iloc[prev]:
                final_upperband.iloc[curr] = final_upperband.iloc[prev]
        if supertrend[curr] == True:
            final_upperband.iloc[curr] = np.nan
        else:
            final_lowerband.iloc[curr] = np.nan

    st = pd.Series(np.where(supertrend, final_lowerband, final_upperband), index=df.index)
    st_dir = pd.Series(np.where(supertrend, 1, -1), index=df.index)
    return st, st_dir

# ==========================================
# MARKET DATA LOGIC (Multi-Timeframe)
# ==========================================
def fetch_nifty_market(interval: str):
    now = datetime.datetime.now()
    if market_cache["data"] is not None and market_cache["last_fetch"] is not None and market_cache["interval"] == interval:
        if (now - market_cache["last_fetch"]).total_seconds() < 60:
            return market_cache["data"]

    period = "60d"
    if interval in ["1m", "2m"]: period = "7d"
    
    df = yf.download("^NSEI", period=period, interval=interval, progress=False)
    if df.empty: return None
    
    if isinstance(df.columns, pd.MultiIndex): df.columns = df.columns.get_level_values(0)
    df.columns = [str(c) for c in df.columns]
    
    df = df[~df.index.duplicated(keep='last')].sort_index()
    
    df['SMA_20'] = df['Close'].rolling(window=20).mean()
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.ewm(alpha=1/14, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/14, adjust=False).mean()
    rs = avg_gain / avg_loss
    df['RSI_14'] = 100 - (100 / (1 + rs))
    df['RSI_SIGNAL'] = df['RSI_14'].ewm(span=14, adjust=False).mean()
    
    # 🔴 v2.1 UPDATE: Injecting the new (8, 2.4) SuperTrend Parameters here 
    df['SUPERTREND'], df['ST_DIR'] = calc_supertrend(df, 8, 2.4)
    
    df = df.dropna()
    market_cache["data"] = df
    market_cache["last_fetch"] = now
    market_cache["interval"] = interval

    gc.collect()
    
    return df

@app.get("/api/market")
def get_market_data(interval: str = "1h", strategy: str = "MONTHLY"):
    df = fetch_nifty_market(interval)
    if df is None or df.empty:
        raise HTTPException(status_code=500, detail="Failed to fetch market data")
    
    latest = df.iloc[-2]
    current = df.iloc[-1]
    
    close = float(latest['Close'])
    sma20 = float(latest['SMA_20'])
    rsi = float(latest['RSI_14'])
    rsi_sig = float(latest['RSI_SIGNAL'])
    supertrend = float(latest['SUPERTREND'])
    
    spot = float(current['Close'])
    is_live = False
    if angel_session:
        try:
            tick = angel_session.ltpData("NSE", "Nifty 50", "26000")
            if tick and isinstance(tick, dict) and tick.get('status'):
                spot = float(tick['data']['ltp'])
                is_live = True
        except Exception: pass

    chart_data = []
    sma_data = []
    st_data = []
    
    for ts, row in df.iterrows():
        t_stamp = int(pd.Timestamp(ts).timestamp()) + 19800 
        chart_data.append({"time": t_stamp, "open": float(row['Open']), "high": float(row['High']), "low": float(row['Low']), "close": float(row['Close'])})
        sma_data.append({"time": t_stamp, "value": float(row['SMA_20'])})
        st_data.append({"time": t_stamp, "value": float(row['SUPERTREND'])})
        
    if is_live and len(chart_data) > 0:
        chart_data[-1]['close'] = spot
        if spot > chart_data[-1]['high']: chart_data[-1]['high'] = spot
        if spot < chart_data[-1]['low']: chart_data[-1]['low'] = spot

    signal = "NEUTRAL (WAIT)"
    details = "Market is ranging or conditions not met. Hold positions or wait for clear trend."
    
    if strategy == "MONTHLY":
        if rsi > rsi_sig and spot > sma20: 
            signal = "🟢 ENTER BULL PUT"
            details = "ACTION: Sell Put at 20-25 Delta and Buy Put 300 points below selling strike."
        elif rsi < rsi_sig and spot < sma20: 
            signal = "🔴 ENTER BEAR CALL"
            details = "ACTION: Sell Call at 20-25 Delta and Buy Call 1000 points above selling strike."
            
    elif strategy == "WEEKLY":
        prev_st_dir = latest['ST_DIR']
        curr_st_dir = current['ST_DIR']
        
        if prev_st_dir == -1 and curr_st_dir == 1:
            signal = "🟢 BULL PUT SPREAD ENTRY"
            details = "1H Candle closed above SuperTrend. Sell Put Nifty weekly expiry (25-30 Delta), Buy Put below 200 points. Enter at 15hrs EOD."
        elif prev_st_dir == 1 and curr_st_dir == -1:
            signal = "🔴 BEAR CALL SPREAD ENTRY"
            details = "1H Candle closed below SuperTrend. Sell Call Nifty weekly expiry (25-30 Delta), Buy Call above 200 points. Enter at 15hrs EOD."
        elif curr_st_dir == 1:
            signal = "HOLD BULLISH"
            details = "SuperTrend is green. Exit Bull Put positions if any 1-hour candle closes below SuperTrend."
        elif curr_st_dir == -1:
            signal = "HOLD BEARISH"
            details = "SuperTrend is red. Exit Bear Call positions if any 1-hour candle closes above SuperTrend."

    return {
        "spot": spot, "is_live": is_live,
        "indicators": {"sma20": sma20, "rsi": rsi, "rsi_sig": rsi_sig, "supertrend": supertrend},
        "algo": {"signal": signal, "details": details},
        "chart_data": chart_data, "sma_data": sma_data, "supertrend_data": st_data
    }

@app.get("/api/options_chain")
def get_options_chain():
    if opts_df.empty: return {"expiries": [], "strikes": []}
    return {"expiries": opts_df['expiry'].unique().tolist(), "strikes": sorted(opts_df['strike_price'].unique().tolist())}

class PriceRequest(BaseModel):
    expiry: str
    legs: list

@app.post("/api/live_prices")
def get_live_prices(req: PriceRequest):
    if opts_df.empty or not angel_session:
        return {"prices": {f"{l['strike']}_{l['type']}": 0.0 for l in req.legs}}
        
    exp_df = opts_df[opts_df['expiry'] == req.expiry]
    results = {}
    
    for leg in req.legs:
        key = f"{leg['strike']}_{leg['type']}"
        try:
            row = exp_df[(exp_df['strike_price'] == leg['strike']) & (exp_df['symbol'].str.endswith(leg['type']))].iloc[0]
            tick = angel_session.ltpData("NFO", row['symbol'], row['token'])
            if tick and isinstance(tick, dict) and tick.get('status'):
                results[key] = float(tick['data']['ltp'])
            else: results[key] = 0.0
        except: results[key] = 0.0
            
    return {"prices": results}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)